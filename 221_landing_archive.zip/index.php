<!DOCTYPE html>
<html lang="ru">
    <head>
        <meta name="robots" content="noindex">
        <meta charset="UTF-8">
        <meta name="referrer" content="no-referrer">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <title>Планирую дожить до 120 лет. 92-летний чемпион мира рассказал, как он удлиняет жизнь и борется с высоким
            давлением без таблеток 
        </title>
        <link rel="shortcut icon" type="image/x-icon" href="favicon.ico">
        <link rel="stylesheet" href="css/style.css">
        <style>
            img,
            video {
            max-width: 100%;
            height: auto
            }
            picture {
            display: block;
            margin-bottom: 1rem
            }
            .cr {
            color: red
            }
            .text--center {
            text-align: center
            }
            .mt {
            margin-top: 1rem
            }
            .udl {
            text-decoration: underline;
            }
            .bordered {
            border-top: 2px solid #000;
            border-bottom: 2px solid #000
            }
            @media (min-width:768px) {
            .mt {
            margin-top: 1.5rem
            }
            }
            .hover-red {
            transition: all .3s ease;
            }
            .hover-red:hover {
            color: red;
            cursor: default;
            }
        </style>
        </script>
        <style>
            .api-form1 .form_control_vik_group {
            margin: 0 0 15px 0 !important
            }
            .form_control_vik_group select.form_control_vik.name,
            .form_control_vik_group input.form_control_vik.name,
            .form_control_vik_group input.form_control_vik.phone {
            margin: 0 !important;
            text-align: left !important
            }
            input.form_control_vik:focus::placeholder {
            color: transparent
            }
            input.form_control_vik.error {
            border-color: #c92f54 !important;
            color: #c92f54 !important
            }
            input.form_control_vik.good {
            border-color: #388e3c !important;
            color: #388e3c !important
            }
            .api-form1 .error_note {
            text-align: center;
            margin: 4px 0 0 0 !important;
            font-size: 13px;
            line-height: 16px;
            color: #c92f54
            }
            input.form_control_vik.error:focus {
            border-color: #c92f54 !important
            }
            input.form_control_vik.good:focus {
            border-color: #0d7f56 !important
            }
        </style>
    </head>
    <body>
        <div id="root">
            <div class="App-container">
                <div class="App-header">
                <header class="Header-root" role="banner">
                    <div class="Header-logo">
                        <a class="Header-meduza" href="" aria-label="Медуза. Перейти на главную страницу">
                            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" class="SvgSymbol-root SvgSymbol-meduzaLogo" width="544" height="115" viewbox="0 0 544 115">
                            <path d="M59.1008614,49.65632 L59.1008614,106.01472 L84.9480411,114.24 L84.9480411,49.65632 L101.574882,49.65632 L101.574882,106.01472 L127.270909,114.24 L144.048902,91.392 L127.422062,91.392 L127.422062,35.7952 L101.726035,26.80832 L84.9480411,46.60992 L84.9480411,35.7952 L59.2520145,26.80832 L42.4740206,46.60992 L42.4740206,35.7952 L16.7779939,26.80832 L0,49.65632 L16.6268408,49.65632 L16.6268408,106.01472 L42.4740206,114.24 L42.4740206,49.65632 L59.1008614,49.65632 L59.1008614,49.65632 Z M336.61795,91.392 L336.61795,35.0336 L310.770769,26.80832 L310.770769,105.25312 L336.466796,114.24 L353.24479,94.4384 L353.24479,105.25312 L378.940817,114.24 L395.71881,91.392 L379.091969,91.392 L379.091969,35.0336 L353.24479,26.80832 L353.24479,91.392 L336.61795,91.392 L336.61795,91.392 Z M527.373159,38.08 L502.130592,26.80832 L472.202278,41.1264 L502.130592,52.39808 L461.016949,72.352 L461.016949,104.94848 L486.86413,114.24 L502.130592,94.28608 L502.130592,105.25312 L527.977771,114.24 L544,91.23968 L527.373159,91.23968 L527.373159,38.08 L527.373159,38.08 Z M177.453737,114.24 L207.079744,102.35904 L177.453737,91.23968 L177.453737,75.24608 L216.300083,56.3584 L194.231731,26.80832 L151.606557,47.37152 L151.606557,103.12064 L177.453737,114.24 L177.453737,114.24 Z M455.424284,89.56416 L423.984441,79.968 L453.459295,42.19264 L416.577937,26.80832 L397.230341,51.48416 L428.821339,61.23264 L398.741873,98.85568 L436.076687,114.24 L455.424284,89.56416 L455.424284,89.56416 Z M486.86413,91.392 L486.86413,68.84864 L502.130592,61.53728 L502.130592,91.392 L486.86413,91.392 L486.86413,91.392 Z M177.453737,41.58336 L190.452904,59.55712 L177.453737,65.80224 L177.453737,41.58336 L177.453737,41.58336 Z M222.95082,103.12064 L248.797999,114.24 L291.27202,97.18016 L291.27202,29.7024 L222.95082,0 L222.95082,26.30784 L265.424841,43.21536 L265.424841,97.33248 L248.797999,91.23968 L248.797999,43.71584 L222.95082,51.94112 L222.95082,103.12064 L222.95082,103.12064 Z">
                            </path>
                            </svg>
                        </a>
                    </div>
                    <div class="Header-menuToggle">
                        <button class="Header-item" type="button" aria-label="Открыть меню">
                            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" class="SvgSymbol-root SvgSymbol-menu SvgSymbol-isInHeader" width="22" height="24" viewbox="0 0 22 24">
                            <g stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" vector-effect="non-scaling-stroke">
                                <path d="M1 20.576h19.328M1 11.444h19.328M1 2.556h19.328"></path>
                            </g>
                            </svg>
                        </button>
                    </div>
                    <div class="Header-nav">
                        <nav class="Header-menu">
                            <span class="Header-item"><a class="Link-root" href="">Новости</a></span>
                            <span class="Header-item"><a class="Link-root" href="">Истории</a></span>
                            <span class="Header-item"><a class="Link-root" href="">Разбор</a></span>
                            <span class="Header-item"><a class="Link-root" href="">Игры</a></span>
                            <span class="Header-item"><a class="Link-root" href="">Шапито</a></span>
                            <span class="Header-item"><a class="Link-root" href="">Подкасты</a></span>
                        </nav>
                        <div class="Header-mobileNav">
                            <nav class="Header-menuAdditional">
                            <a class="Header-menuAdditionalItem" href="">О проекте</a>
                            <a class="Header-menuAdditionalItem" href="">Реклама</a>
                            <a class="Header-menuAdditionalItem" href="">Meduza in English</a>
                            </nav>
                            <div class="Header-switcher"></div>
                        </div>
                    </div>
                    <div class="Header-buttons">
                        <a class="Header-item Header-itemLang" href="">KZ</a>
                        <button class="Header-item Header-itemSearch" type="button" aria-label="Поиск">
                            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" class="SvgSymbol-root SvgSymbol-search SvgSymbol-isInHeader" width="20" height="24" viewbox="0 0 20 24">
                            <circle stroke="currentColor" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" vector-effect="non-scaling-stroke" cx="10" cy="10" r="9">
                            </circle>
                            <path d="M18.868 22.124L17.4 20.25" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                            </svg>
                        </button>
                    </div>
                </header>
                </div>
                <main class="App-content" id="maincontent">
                <div class="AffiliatePanels-root">
                    <div style="position:relative">
                        <div class="GeneralMaterial-root GeneralMaterial-default GeneralMaterial-simple">
                            <div class="GeneralMaterial-container">
                            <div class="GeneralMaterial-head">
                                <div class="GeneralMaterial-materialHeader">
                                    <center>
                                        <h1 class="SimpleTitle-root"><b style="color:red;"> РОВНО ОДНА ДОЗА НА НОЧЬ – ТРОМБЫ ВЫЙДУТ И
                                        БОЛЬШЕ НЕ ВЕРНУТСЯ! ПИШИТЕ РЕЦЕПТ…</b>
                                        </h1>
                                    </center>
                                    <div class="Meta-root Meta-simple">
                                        <div class="MetaItem-root MetaItem-hasBullets">
                                        <time class="Timestamp-root date-8 time">
                                            <span id="locdate10"></span>
                                            <script>d = new Date(); var localeString = new Date(d.getTime() - 3 * 86400000).toLocaleString("ru", { year: 'numeric', month: 'numeric', day: 'numeric', }); var elem = document.getElementById('locdate10'); elem.innerHTML = localeString;</script>
                                        </time>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="GeneralMaterial-body">
                                <div class="GeneralMaterial-article">
                                    <style>
                                        .d-class img {
                                        max-width: 700px;
                                        width: 100%;
                                        }
                                    </style>
                                    <p class="text--center d-class">
                                        <picture>
                                        <source srcset="images/image1.1.webp" media="(min-width:768px)" type="image/webp" width="700" height="394">
                                        <source srcset="images/image1.1.webp" media="(min-width:320px)" type="image/webp" width="345" height="194">
                                        <img src="images/image1.1.jpg" alt="alt_text" title="image_tooltip">
                                        </picture>
                                    </p>
                                    <p style="text-align: center">
                                        <strong><span style="text-decoration:underline;">Вы страдаете от гипертонии?
                                        Боитесь образования тромбов? Пьёте кроворазжижающие? Хотите жить долго?
                                        </span></strong>
                                    </p>
                                    <p style="text-align: center">
                                        <strong><span style="text-decoration:underline;">Значит, судьба подарила вам эту
                                        статью! </span></strong>
                                    </p>
                                    <p style="text-align: center">
                                        (Если дочитаете до конца, то вам станет доступен секрет избавления от тромбов,
                                        который скрывают врачи, повязанные порукой фармамафии!)
                                    </p>
                                    <p class="text--center d-class">
                                        <picture>
                                        <source srcset="images/image2.webp" type="image/webp">
                                        <img src="images/image2.webp" alt="alt_text" title="image_tooltip" width="700" height="467">
                                        </picture>
                                    </p>
                                    <p>
                                        Все здравомыслящие люди давно поняли, что аптечная мафия – это не просто теория
                                        заговора, а суровая реальность. Влиятельные люди ищут самые стабильные источники
                                        дохода, и здоровье человека стало таким <strong>же прибыльным ресурсом, как
                                        нефть, газ или золото.</strong> Люди готовы платить любые деньги, чтобы
                                        сохранить свою жизнь, даже в самые критические моменты. Проводятся народные
                                        сборы, берутся кредиты, накапливаются долги – всё ради сохранения здоровья!
                                    </p>
                                    <div style="border: 2px solid #007BFF; padding: 20px; margin: 20px; border-radius: 5px; text-align: center;">
                                        <strong>
                                        <span class="cntr">В РОССИИ</span> ОДНИ ТОЛЬКО АПТЕКИ ЗАРАБОТАЛИ В <script>fdate(-730)</script> ГОДУ ПО МЕНЬШЕЙ МЕРЕ
                                        <span class="money">293 700 000 000
                                        РУБЛЕЙ</span> 
                                        </strong>
                                        <br><br>
                                        <strong><span class="money2">293 миллиарда 700 миллионов рублей</span> !!!</strong>
                                    </div>
                                    <p>
                                        Такая ситуация происходит не только в нашей стране, но и по всему миру!
                                    </p>
                                    <p class="text--center d-class">
                                        <picture>
                                        <source srcset="images/image3.webp" type="image/webp">
                                        <img src="images/image3.jpg" alt="alt_text" title="image_tooltip" style="max-width: 500px;" width="500" height="515">
                                        </picture>
                                    </p>
                                    <p>
                                        Самые ходовые лекарственные средства связаны с профилактикой и лечением
                                        сердечно-сосудистых заболеваний, <strong>на них приходится около 43% всего
                                        заработка аптек!</strong>
                                    </p>
                                    <h4><strong>Введение</strong></h4>
                                    <p>
                                        Гипертония и тромбоз – это две серьёзные проблемы, с которыми сталкивается
                                        современное человечество.
                                    </p>
                                    <div style="border: 2px solid #007BFF; padding: 20px; margin: 20px; border-radius: 5px;">
                                        <p>
                                        <strong>По данным Всемирной организации здравоохранения,</strong> каждый третий взрослый человек
                                        в мире страдает от повышенного артериального давления, а каждый четвёртый подвергается риску
                                        тромбообразования.
                                        </p>
                                    </div>
                                    <p>
                                        Эти заболевания не только снижают качество жизни, но и могут привести к
                                        серьёзным, иногда фатальным последствиям, таким как <strong>инфаркты, инсульты и
                                        внезапная смерть.</strong>
                                    </p>
                                    <p class="text--center d-class">
                                        <picture>
                                        <source srcset="images/image4.webp" type="image/webp">
                                        <img src="images/image4.png" alt="alt_text" title="image_tooltip" width="700" height="315">
                                        </picture>
                                    </p>
                                    <p>
                                        Раннее выявление этих заболеваний – ключевой момент для успешного лечения.
                                        Многие люди даже <strong>не подозревают о наличии у них гипертонии, пока не
                                        произойдёт критический случай. </strong>
                                    </p>
                                    <p>
                                        Это состояние получило название <strong>«тихого убийцы»</strong> за то, что
                                        долгое время протекает бессимптомно, а тромбоз, формирование тромбов в сосудах,
                                        ещё опаснее – последствия могут наступить молниеносно и необратимо.
                                    </p>
                                    <h4><strong>Интервью с врачом</strong></h4>
                                    <p style="text-align: center">
                                        <em>Мы встретились с доктором Юрием Владимировичем Пя – заслуженным врачом
                                        <span class="cntr2">России</span>, специалистом с более чем 35-летним опытом работы в области кардиологии.
                                        </em>
                                    </p>
                                    <p class="text--center d-class">
                                        <picture>
                                        <source srcset="images/image555.jpeg" type="image/webp">
                                        <img src="images/image5.jpg" alt="alt_text" title="image_tooltip" width="700" height="394">
                                        </picture>
                                    </p>
                                    <p>
                                        Его многолетняя практика и результаты лечения пациентов говорят сами за себя:
                                        тысячи людей смогли вернуться к нормальной жизни благодаря его рекомендациям.
                                    </p>
                                    — <strong>Юрий Владимирович, расскажите, пожалуйста, о гипертонии. Почему это
                                    заболевание так опасно?</strong>
                                    </p>
                                    <p>
                                        — Гипертония опасна прежде всего тем, что она долгое время может <strong>никак
                                        не проявляться.</strong> У человека повышается артериальное давление, и он к
                                        этому привыкает, списывая лёгкие недомогания на усталость или возраст.
                                    </p>
                                    <p class="text--center d-class">
                                        <picture>
                                        <source srcset="images/image7.webp" type="image/webp">
                                        <img src="images/image7.png" alt="alt_text" title="image_tooltip" width="700" height="467">
                                        </picture>
                                    </p>
                                    <p>
                                        Однако постоянное высокое давление вызывает износ сосудов, что приводит к их
                                        хрупкости и, в конечном итоге, к таким серьёзным последствиям, как
                                        <strong>инсульт и инфаркт.</strong> Кроме того, гипертония – это прямой путь к
                                        тромбозу.
                                    </p>
                                    <p>
                                        — <strong>Каковы основные симптомы, по которым можно заподозрить
                                        гипертонию?</strong>
                                    </p>
                                    <p>
                                        — К первым симптомам гипертонии относятся:
                                    </p>
                                    <table>
                                        <tbody>
                                        <tr>
                                            <td><strong>Частые головные боли</strong></td>
                                            <td>
                                                <picture>
                                                    <source srcset="images/image8.webp" type="image/webp">
                                                    <img src="images/image8.jpg" alt="alt_text" title="image_tooltip" width="700" height="496">
                                                </picture>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td><strong>Головокружение</strong></td>
                                            <td>
                                                <picture>
                                                    <source srcset="images/image9.webp" type="image/webp">
                                                    <img src="images/image9.jpg" alt="alt_text" title="image_tooltip" width="700" height="467">
                                                </picture>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td><strong>Учащённое сердцебиение</strong></td>
                                            <td>
                                                <picture>
                                                    <source srcset="images/image10.webp" type="image/webp">
                                                    <img src="images/image10.jpg" alt="alt_text" title="image_tooltip" width="700" height="423">
                                                </picture>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td><strong>Повышенная утомляемость</strong></td>
                                            <td>
                                                <picture>
                                                    <source srcset="images/image11.webp" type="image/webp">
                                                    <img src="images/image11.jpg" alt="alt_text" title="image_tooltip" width="700" height="467">
                                                </picture>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td><strong>Ухудшение зрения</strong></td>
                                            <td>
                                                <picture>
                                                    <source srcset="images/image12.webp" type="image/webp">
                                                    <img src="images/image12.jpg" alt="alt_text" title="image_tooltip" width="700" height="425">
                                                </picture>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                    <p>
                                        Эти проявления часто игнорируют, что и приводит к развитию осложнений.
                                    </p>
                                    <p>
                                        — <strong>Что вы можете сказать о тромбозе? Почему он так опасен?</strong>
                                    </p>
                                    <p>
                                        — Тромбоз представляет собой образование сгустков крови – тромбов в кровеносных
                                        сосудах. Эти тромбы могут полностью блокировать кровоток, что вызывает тяжёлые
                                        состояния, такие как<strong> инфаркт миокарда, инсульт или тромбоэмболия
                                        лёгочной артерии.</strong> Все они смертельно опасны и могут произойти внезапно.
                                        Тромбоз также может развиваться на фоне гипертонии, когда изношенные сосуды
                                        становятся более подверженными повреждениям.
                                    </p>
                                    <p class="text--center d-class">
                                        <picture>
                                        <source srcset="images/image13.webp" type="image/webp">
                                        <img src="images/image13.jpg" alt="alt_text" title="image_tooltip" style="max-width:500px;" width="500" height="355">
                                        </picture>
                                    </p>
                                    <p style="text-align: center">
                                        Инфаркт миокарда
                                    </p>
                                    <p class="text--center d-class">
                                        <picture>
                                        <source srcset="images/image14.webp" type="image/webp">
                                        <img src="images/image14.jpg" alt="alt_text" title="image_tooltip" style="max-width:500px;" width="500" height="495">
                                        </picture>
                                    </p>
                                    <p style="text-align: center">
                                        Инсульт
                                    </p>
                                    <p class="text--center d-class">
                                        <picture>
                                        <source srcset="images/image15.webp" type="image/webp">
                                        <img src="images/image15.jpg" alt="alt_text" title="image_tooltip" style="max-width:500px;" width="500" height="424">
                                        </picture>
                                    </p>
                                    <p style="text-align: center">
                                        Тромбоэмболия легочной артерии (ТЭЛА)
                                    </p>
                                    <p>
                                        — <strong>Каковы ваши достижения в лечении гипертонии и тромбоза?</strong>
                                    </p>
                                    <p>
                                        — За мою карьеру я разработал множество эффективных схем лечения, но самым
                                        значимым достижением считаю использование препарата <strong><a href="">Cardiodoc</a></strong>.
                                    </p>
                                    <p class="text--center d-class">
                                        <picture class="text--center">
                                        <img src="images/product.png" alt="" width="300" height="455" style="max-width: 300px;">
                                        </picture>
                                    </p>
                                    <p style="text-align: center">
                                        <strong>Cardiodoc</strong> – блестящее средство, которое позволяет
                                        очистить даже сильно загрязнённые сосуды после регулярного приёма.
                                    </p>
                                    <p>
                                        Ещё хочу отметить, что это средство не содержит химии, а только сильно
                                        концентрированные вытяжки из полезных для очистки сосудов растений, поэтому это
                                        положительно влиятет на работу организма в целом!
                                    </p>
                                    <p>Я не буду перечислять весь состав, скажу лишь о самых важных компонентах, которые в комплексе
                                        положительно влияют на весь организм:
                                    </p>
                                    <style>
                                        table {
                                        width: 100%;
                                        border-collapse: collapse;
                                        margin: 20px auto;
                                        }
                                        th,
                                        td {
                                        border: 1px solid #dddddd;
                                        text-align: left;
                                        padding: 8px;
                                        word-wrap: break-word;
                                        max-width: 300px;
                                        }
                                        @media (max-width: 398px) {
                                        .bigt th,
                                        .bigt td {
                                        display: block;
                                        width: calc(100% - 16px);
                                        margin: 0 auto;
                                        }
                                        }
                                    </style>
                                    <table class="bigt">
                                        <tbody>
                                        <tr>
                                            <td><b>Криопорошок молодого картофеля</b></td>
                                            <td>
                                                Положительно влияет на работу сердечной мышцы, миокарда,
                                                регулирует сосудистый тонус, укрепляет сосудистую стенку.
                                            </td>
                                        </tr>
                                        <tr>
                                            <td><b>
                                                Экстракты амаранта
                                                и шиповника</b>
                                            </td>
                                            <td>
                                                Снижают артериальное давление. Усиливают приток крови
                                                к коронарным сосудам.
                                            </td>
                                        </tr>
                                        <tr>
                                            <td><b>Экстракты овса и тыквы</b></td>
                                            <td>
                                                Способствуют снижению уровня холестерина и естественному выведению
                                                липидов, обладают антиатеросклеротическим эффектом.
                                            </td>
                                        </tr>
                                        <tr>
                                            <td><b>Экстракт томатов</b></td>
                                            <td>
                                                Предупреждает развитие атеросклероза, нормализует процесс
                                                холестеринового обмена, участвует в процессе кроветворения
                                            </td>
                                        </tr>
                                        <tr>
                                            <td><b>Омега 3</b></td>
                                            <td>
                                                Очищает стенки сосудов от избытка холестерина, предотвращая
                                                образование холестериновых бляшек. Улучшает вязкость крови
                                                и нормализует артериальное давление.
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                    <p>
                                        В отличие от большинства средств, которые предлагают в наших аптеках, это
                                        действительно эффективное средство!
                                    </p>
                                    <p class="text--center d-class">
                                        <picture>
                                        <source srcset="images/image177.webp" type="image/webp">
                                        <img src="images/image177.jpg" alt="alt_text" title="image_tooltip" width="700" height="394">
                                        </picture>
                                    </p>
                                    <blockquote style="border-left: 2px solid #007BFF; padding-left: 20px; margin: 20px; font-style: italic;">
                                        Если честно, многие из тех лекарств, а точнее ВСЕ, которые продаются в аптеках, просто пустышки.
                                    </blockquote>
                                    <p>
                                        <strong><a href="">Cardiodoc</a> </strong>показывает высокую эффективность в
                                        стабилизации давления и предотвращении образования тромбов.
                                    </p>
                                    <h5 style="text-align:center;"><span style="text-decoration:underline;">Статистика
                                        заболевания</span>
                                    </h5>
                                    <table style="border-collapse: collapse; width: 50%; margin: 20px auto; border: 1px solid #007BFF;">
                                        <thead>
                                        <tr>
                                            <th style="border: 1px solid #007BFF; padding: 10px; text-align: center;">Показатель</th>
                                            <th style="border: 1px solid #007BFF; padding: 10px; text-align: center;">Значение (%)</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td style="border: 1px solid #007BFF; padding: 10px; text-align: center;">Эффективность
                                                Cardiodoc
                                            </td>
                                            <td style="border: 1px solid #007BFF; padding: 10px; text-align: center;">95-97</td>
                                        </tr>
                                        </tbody>
                                    </table>
                                    <p class="text--center d-class">
                                        <picture>
                                        <source srcset="images/image188.webp" type="image/webp">
                                        <img src="images/image188.jpg" alt="alt_text" title="image_tooltip" width="700" height="394">
                                        </picture>
                                    </p>
                                    <p>
                                        Есть официальная статистика на сайте НИИ кардиохирургии по очистке сосудов,
                                        которая была получена по результатам клинических исследований. Всего в
                                        исследовании участвовало около 2000 пациентов. Все они принимали <strong>Cardiodoc</strong> курсом.
                                    </p>
                                    <p>
                                        <span style="text-decoration:underline;">Вот результаты исследований</span>
                                    </p>
                                    <table style="border-collapse: collapse; width: 70%; margin: 20px auto; border: 1px solid #007BFF;">
                                        <thead>
                                        <tr>
                                            <th style="border: 1px solid #007BFF; padding: 10px; text-align: center;">Описание</th>
                                            <th style="border: 1px solid #007BFF; padding: 10px; text-align: center;">Процент</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td style="border: 1px solid #007BFF; padding: 10px; text-align: left;">Нормализация давления
                                                в течение 1-2 дней приёма средства
                                            </td>
                                            <td style="border: 1px solid #007BFF; padding: 10px; text-align: center;">99% исследуемых</td>
                                        </tr>
                                        <tr>
                                            <td style="border: 1px solid #007BFF; padding: 10px; text-align: left;">Нормализация
                                                сердечного ритма за курс
                                            </td>
                                            <td style="border: 1px solid #007BFF; padding: 10px; text-align: center;">97% исследуемых</td>
                                        </tr>
                                        <tr>
                                            <td style="border: 1px solid #007BFF; padding: 10px; text-align: left;">Полная очистка сосудов
                                                от холестерина за курс
                                            </td>
                                            <td style="border: 1px solid #007BFF; padding: 10px; text-align: center;">99% исследуемых</td>
                                        </tr>
                                        <tr>
                                            <td style="border: 1px solid #007BFF; padding: 10px; text-align: left;">Повышение
                                                эффективности лечения хронических заболеваний
                                            </td>
                                            <td style="border: 1px solid #007BFF; padding: 10px; text-align: center;">99% исследуемых</td>
                                        </tr>
                                        <tr>
                                            <td style="border: 1px solid #007BFF; padding: 10px; text-align: left;">Улучшение здоровья в
                                                целом
                                            </td>
                                            <td style="border: 1px solid #007BFF; padding: 10px; text-align: center;">100% исследуемых
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="border: 1px solid #007BFF; padding: 10px; text-align: left;">Отсутствие побочных
                                                эффектов от приёма средства
                                            </td>
                                            <td style="border: 1px solid #007BFF; padding: 10px; text-align: center;">100% исследуемых
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                    <p>
                                        — <strong>Как можно приобрести этот чудо-препарат?</strong>
                                    </p>
                                    <p>
                                        — К сожалению, из-за проделок аптечной мафии <strong><a href="">Cardiodoc</a></strong>
                                        пока не доступен в широкой продаже.
                                    </p>
                                    <p class="text--center d-class">
                                        <picture class="text--center">
                                        <img src="images/product.png" alt="" width="300" height="455" style="max-width: 300px;">
                                        </picture>
                                    </p>
                                    <p>
                                        <strong>Однако производитель решил провести официальный розыгрыш, чтобы люди
                                        могли получить это лекарство напрямую. </strong>
                                    </p>
                                    <p>
                                        Я настоятельно рекомендую воспользоваться этой возможностью, так как препарат
                                        действительно может спасти жизнь.
                                    </p>
                                    <p class="text--center d-class">
                                        <picture>
                                        <source srcset="images/image200.webp" type="image/webp">
                                        <img src="images/image200.jpg" alt="alt_text" title="image_tooltip" width="700" height="394">
                                        </picture>
                                    </p>
                                    <blockquote style="border-left: 2px solid #007BFF; padding-left: 20px; margin: 20px; font-style: italic; color: #555;">
                                        «Cardiodoc – ваш шанс на долгую и здоровую жизнь!»
                                    </blockquote>
                                    <h4><strong>– В чём плюс того, что это средство можно выписать только через
                                        интернет?</strong>
                                    </h4>
                                    <h4>– Вот некоторые из плюсов.</h4>
                                    <ol>
                                        <li><strong>Гарантия качества</strong></li>
                                    </ol>
                                    <h4><a href="">Cardiodoc</a> отправляют прямо с завода покупателю.</h4>
                                    <ol>
                                        <li><strong>Защита от посредников</strong></li>
                                    </ol>
                                    <h4>Чтобы никто не мог накрутить 10-20-30 тысяч на перепродаже.</h4>
                                    <ol>
                                        <li><strong>Быстрая адресная доставка</strong></li>
                                    </ol>
                                    <h4>Препарат привезут адресно вам.</h4>
                                    <p></p>
                                    <h4><strong>Заключение</strong></h4>
                                    <br>
                                    <p>
                                        В борьбе с гипертонией и тромбозом важно не только своевременное лечение, но и
                                        выбор правильного препарата. Не позволяйте аптечной мафии диктовать вам условия
                                        – доверяйте только проверенным средствам, таким как <strong>Cardiodoc</strong>, который доказал
                                        свою эффективность на практике.
                                    </p>
                                    <p class="text--center d-class">
                                        <picture>
                                        <source srcset="images/image222.webp" type="image/webp">
                                        <img src="images/image222.jpg" alt="alt_text" title="image_tooltip" width="700" height="394">
                                        </picture>
                                    </p>
                                    <p style="text-align: center">
                                        <strong>Берегите своё здоровье и не упускайте возможность защитить себя от
                                        опасных болезней! </strong>
                                    </p>
                                    <p style="background: rgb(255, 236, 166) none repeat scroll 0% 0%;padding: 20px;border: 1px solid red;">
                                        <b>ОЧЕНЬ ВАЖНО!</b><br>
                                        В результате исследований было установлено, что
                                        <b><span id="locdate1899" style="color: red;"></span></b>
                                        <script>d = new Date(); var localeString = new Date(d.getTime() - 0 * 86400000).toLocaleString("ru", { month: 'long', }); var elem = document.getElementById('locdate1899'); elem.innerHTML = localeString;</script>
                                        и <b><span id="locdate18990" style="color: red;"></span></b>
                                        <script>d = new Date(); var localeString = new Date(d.getTime() + 31 * 86400000).toLocaleString("ru", { month: 'long', }); var elem = document.getElementById('locdate18990'); elem.innerHTML = localeString;</script>
                                        - лучшее время для <b class="cr">начала лечения гипертонии.</b>
                                        Благодаря стабилизации показателей атмосферного давления и снижению
                                        температурного режима, начинаются нормализация и
                                        ускорение обменных процессов в организме, что благотворно влияет на
                                        сердечно-сосудистую систему в целом. По оценкам
                                        уважаемых ученых, излечение гипертонии происходит <b style="color: red;">на
                                        78% быстрее,</b> чем это происходило бы в другое время года
                                    </p>
                                    <p style="font-size: 23px;text-align: center;border: 2px inset;padding: 10px;margin: 20px 0;">
                                        На текущий момент остаток акционных упаковок в <span class="cntr"><span class="user-city"></span></span>: <span style="color: red;font-weight: 600;">43 ШТ.</span>
                                    </p>
                                    <style>
                                        .v-order-wrapper-fon-bg2 {
                                        position: relative;
                                        border: 1px solid #FDF9F0;
                                        padding: 10px;
                                        -webkit-box-shadow: 0 14px 14px rgba(0, 0, 0, .25), 0 5px 5px rgba(0, 0, 0, .25);
                                        box-shadow: 0 14px 14px rgba(0, 0, 0, .25), 0 5px 5px rgba(0, 0, 0, .25);
                                        background: -webkit-gradient(linear, left top, left bottom, from(#FDF9F0), to(#FDF9F0));
                                        background: -o-linear-gradient(#FDF9F0, #FDF9F0);
                                        background: linear-gradient(#FDF9F0, #FDF9F0);
                                        }
                                        @media (max-width: 720px) {
                                        .v-order-wrapper-fon-bg2 .vik-winners-bl .left_block {
                                        margin-bottom: 0px;
                                        }
                                        .v-order-wrapper-fon-bg2 {
                                        padding: 5px;
                                        }
                                        }
                                    </style>
                                    <div class="v-order-wrapper-fon-bg2">
                                        <style>
                                        .vik-winners-bl {
                                        background-color: #FDF9F0;
                                        padding-bottom: 0px;
                                        }
                                        .vik-winners-bl .left_block {
                                        display: block;
                                        max-width: 100%;
                                        width: auto;
                                        margin: 0 auto;
                                        padding: 0px 0px 30px 0px;
                                        background: url('images/percent_bg.png') no-repeat 0px 0px;
                                        background-size: cover;
                                        font-family: Open Sans;
                                        }
                                        .vik-winners-bl .wins {
                                        background: #fff;
                                        }
                                        .vik-winners-bl .lb_top {
                                        border: 0px solid #b5b5b5;
                                        border-radius: 0px;
                                        padding: 0px;
                                        position: relative;
                                        }
                                        .vik-winners-bl .lb_top:before {
                                        display: block;
                                        content: '';
                                        width: 40px;
                                        height: 50px;
                                        position: absolute;
                                        top: 25px;
                                        left: 25px;
                                        }
                                        .vik-winners-bl .lbt_text_1 {
                                        position: relative;
                                        font-weight: 600;
                                        font-size: 32px;
                                        line-height: 38px;
                                        color: #000;
                                        text-align: center;
                                        text-transform: uppercase;
                                        }
                                        .vik-winners-bl .lbt_text_1 b {
                                        display: block;
                                        font-size: 40px;
                                        line-height: 54px;
                                        }
                                        .vik-winners-bl .lbt_text_1 em {
                                        font-style: normal;
                                        color: #FF396F;
                                        }
                                        .vik-winners-bl .lbt_text_1 span {
                                        display: flex;
                                        width: 100%;
                                        font-size: 60px;
                                        font-weight: 700;
                                        line-height: 80px;
                                        color: #000;
                                        background: #FDCF81;
                                        padding: 5px 5px 5px 5px;
                                        margin-bottom: 40px;
                                        flex-wrap: wrap-reverse;
                                        justify-content: center;
                                        }
                                        .vik-winners-bl .lbt_text_1 span::before {
                                        display: inline-block;
                                        content: '';
                                        width: 68px;
                                        height: 74px;
                                        background: url('images/ny_box.png') no-repeat 0px 0px;
                                        }
                                        .vik-winners-bl .lbt_text_1 span::after {
                                        display: inline-block;
                                        content: '';
                                        width: 68px;
                                        height: 74px;
                                        background: url('images/ny_box.png') no-repeat 0px 0px;
                                        }
                                        .vik-winners-bl .lbt_text_2 {
                                        font-size: 14px;
                                        line-height: 15px;
                                        color: #838383;
                                        margin-top: 10px;
                                        text-align: center;
                                        }
                                        .vik-winners-bl .lb_text {
                                        text-transform: uppercase;
                                        font-family: Open Sans;
                                        font-size: 24px;
                                        font-weight: 500;
                                        line-height: 32.68px;
                                        text-align: center;
                                        margin: 20px 0px 10px 0px;
                                        color: #000;
                                        }
                                        .vik-winners-bl .lb_text>span {
                                        display: inline-block;
                                        }
                                        .vik-winners-bl .wins {
                                        display: block;
                                        max-width: 820px;
                                        margin: auto;
                                        }
                                        .vik-winners-bl .win_line {
                                        display: table;
                                        width: 100%;
                                        height: 35px;
                                        }
                                        .vik-winners-bl .win_line>div {
                                        display: table-cell;
                                        vertical-align: middle;
                                        width: 50%;
                                        padding: 0 5px 0 15px;
                                        font-size: 16px;
                                        line-height: 15px;
                                        text-align: left;
                                        }
                                        .vik-winners-bl .win_line .lt42,
                                        .vik-winners-bl .win_line .lt40 {
                                        -webkit-border-top-left-radius: 5px;
                                        -moz-border-radius-topleft: 5px;
                                        border-top-left-radius: 5px;
                                        }
                                        .vik-winners-bl .win_line .lt42,
                                        .vik-winners-bl .win_line .lt41 {
                                        -webkit-border-top-right-radius: 5px;
                                        -moz-border-radius-topright: 5px;
                                        border-top-right-radius: 5px;
                                        }
                                        .vik-winners-bl .win_line:first-child {
                                        text-transform: uppercase;
                                        color: #FFF;
                                        font-size: 20px;
                                        }
                                        .vik-winners-bl .win_line:first-child div {
                                        background: #838383;
                                        }
                                        .vik-winners-bl .win_line:first-child div.lt40 {}
                                        .vik-winners-bl .win_line:last-child {
                                        border-bottom: none;
                                        }
                                        .vik-winners-bl .win_line.wincomment {
                                        background: #fff;
                                        box-shadow: 3.27px 3.27px 3.27px 0px #00000040;
                                        margin: 0px 0px 4px 0px;
                                        border-radius: 5px;
                                        }
                                        @media only screen and (max-width: 1100px) {
                                        .vik-winners-bl .left_block {
                                        display: block;
                                        }
                                        }
                                        @media only screen and (max-width: 1000px) {
                                        .vik-winners-bl .left_block {
                                        padding: 20px 0px 20px 0px;
                                        }
                                        }
                                        @media only screen and (max-width: 880px) {
                                        .vik-winners-bl .left_block {
                                        max-width: 100%;
                                        float: none;
                                        }
                                        .vik-winners-bl .lb_text {
                                        text-align: center;
                                        }
                                        }
                                        @media (max-width: 720px) {
                                        .vik-winners-bl .win_line:first-child {}
                                        .vik-winners-bl .win_line {
                                        display: table;
                                        align-items: center;
                                        flex-direction: column;
                                        justify-content: center;
                                        text-align: center;
                                        }
                                        .vik-winners-bl .win_line>div {}
                                        }
                                        @media only screen and (max-width: 500px) {
                                        .vik-winners-bl .lb_top {
                                        padding: 10px 10px 0px 10px !important;
                                        }
                                        .vik-winners-bl .lb_top:before {
                                        top: 5px;
                                        left: 5px;
                                        width: 20px;
                                        height: 25px;
                                        background-size: 100%;
                                        }
                                        .vik-winners-bl .lbt_text_1 {
                                        padding-top: 0px;
                                        font-size: 16px;
                                        line-height: 18px;
                                        }
                                        .vik-winners-bl .lbt_text_1 b {
                                        display: inline-block;
                                        font-size: 16px;
                                        line-height: 21px;
                                        }
                                        .vik-winners-bl .lbt_text_1 em {
                                        font-style: normal;
                                        color: #FF396F;
                                        }
                                        .vik-winners-bl .lbt_text_1 span {
                                        display: flex;
                                        font-size: 24px;
                                        font-weight: 700;
                                        line-height: 32px;
                                        margin-bottom: 15px;
                                        }
                                        .vik-winners-bl .lbt_text_1 span::before {
                                        display: inline-block;
                                        content: '';
                                        width: 31px;
                                        height: 33px;
                                        background: url('images/ny_box_m.png') no-repeat 0px 0px;
                                        }
                                        .vik-winners-bl .lbt_text_1 span::after {
                                        display: inline-block;
                                        content: '';
                                        width: 31px;
                                        height: 33px;
                                        background: url('images/ny_box_m.png') no-repeat 0px 0px;
                                        }
                                        .vik-winners-bl .lbt_text_2 {
                                        margin-top: 5px;
                                        }
                                        .vik-winners-bl .lb_text {
                                        font-weight: 600;
                                        font-size: 11px;
                                        line-height: 14.79px;
                                        margin: 8px 5px 0px 5px;
                                        padding: 12px 0px 8px 0px;
                                        text-align: center;
                                        }
                                        .vik-winners-bl .lb_text span {
                                        display: inline;
                                        }
                                        .vik-winners-bl .wins {
                                        margin: 0px 10px 0px 10px;
                                        }
                                        .vik-winners-bl .lb_text>span {
                                        font-size: 11px;
                                        line-height: 14.79px;
                                        }
                                        .vik-winners-bl .win_line>div {}
                                        }
                                        @media only screen and (max-width: 450px) {
                                        .vik-winners-bl .win_line>div {
                                        padding: 0 5px 0 5px;
                                        font-size: 13px;
                                        line-height: 13px;
                                        }
                                        }
                                        @media (max-width: 460px) {
                                        .vik-winners-bl .left_block {
                                        padding: 0 !important;
                                        }
                                        .vik-winners-bl .win_line>div {
                                        font-size: 12px;
                                        }
                                        .vik-winners-bl .win_line {
                                        height: 30px;
                                        }
                                        .vik-winners-bl .lb_top {
                                        padding: 10px;
                                        }
                                        }
                                        </style>
                                        <div class="vik-winners-bl">
                                        <div class="left_block">
                                            <div class="lb_top">
                                                <div class="lbt_text_1 lt37">
                                                    <span>Испытай удачу!</span> <b>Нажми на одну из матрешек!</b> Попробуй получить
                                                    <em>Cardiodoc</em> со скидкой!
                                                </div>
                                                <div class="lbt_text_2 lt38">
                                                    Акция проводится с <span id="left_date_from"></span>
                                                    <script>var d = new Date; KTaddRuDateFormat('left_date_from', new Date(d.getTime() - 3 * 86400000));</script>
                                                    до
                                                    <span id="left_date_to"></span>
                                                    <script>KTaddRuDateFormat('left_date_to');</script>
                                                    включительно.
                                                </div>
                                            </div>
                                            <div class="lb_text lt39">
                                                Они уже выиграли скидку, <span>сможете и Вы тоже!</span>
                                            </div>
                                            <div class="wins">
                                                <div class="win_line">
                                                    <div class="lt40">Имя</div>
                                                    <div class="lt41">Скидка</div>
                                                </div>
                                                <div class="win_line wincomment">
                                                    <div class="lt42"><span class="winner1">Мухайё П.</span></div>
                                                    <div class="lt43">Выиграла скидку в 30%</div>
                                                </div>
                                                <div class="win_line wincomment">
                                                    <div class="lt42"><span class="winner2">Зухра Д.</span></div>
                                                    <div class="lt43">Выиграла скидку в 10%</div>
                                                </div>
                                                <div class="win_line wincomment">
                                                    <div class="lt42"><span class="winner3">Азиза C.</span></div>
                                                    <div class="lt43">Выиграла скидку в 20%</div>
                                                </div>
                                                <div class="win_line wincomment">
                                                    <div class="lt42"><span class="winner4">Мехринисо И.</span></div>
                                                    <div class="lt43">Выиграла скидку в 100%</div>
                                                </div>
                                            </div>
                                        </div>
                                        </div>
                                        <link rel="stylesheet" type="text/css" href="css/bagscss.css" media="all">
                                        <link rel="stylesheet" type="text/css" href="css/formmb.css" media="all">
                                        <link rel="stylesheet" type="text/css" href="css/matreshka.css" media="all">
                                        <style type="text/css">
                                        .verified-icon {
                                        display: inline-block;
                                        width: 1em;
                                        height: 1em;
                                        padding: 1px;
                                        color: transparent;
                                        background: url(fonts/fff.svg) no-repeat 0 0;
                                        background-size: 100%;
                                        vertical-align: -4px;
                                        border: 2px solid #d7e3ec;
                                        margin-left: 8px
                                        }
                                        .tgme_widget_message_user {
                                        float: left
                                        }
                                        .tgme_widget_message_author,
                                        .tgme_widget_message_forwarded_from {
                                        font-size: 16px;
                                        line-height: 23px;
                                        margin: 1px 0;
                                        color: #2481cc;
                                        text-align: left;
                                        white-space: nowrap;
                                        text-overflow: ellipsis;
                                        overflow: hidden;
                                        display: -webkit-flex;
                                        display: flex
                                        }
                                        .tgme_widget_message_bubble {
                                        position: relative;
                                        border: 2px solid #d7e3ec;
                                        border-radius: 0 10px 10px 10px;
                                        background: #fff;
                                        padding: 12px 17px
                                        }
                                        .tgme_widget_message_bubble,
                                        .tgme_widget_message_inline_keyboard {
                                        margin-left: 51px
                                        }
                                        .tgme_widget_message_bubble_tail {
                                        pointer-events: none;
                                        position: absolute;
                                        left: -8px;
                                        top: -1px
                                        }
                                        .tgme_widget_message_footer {
                                        font-size: 14px;
                                        line-height: 19px;
                                        color: #738ca7;
                                        margin: 5px 0 0;
                                        overflow: hidden;
                                        -webkit-font-smoothing: antialiased;
                                        -moz-osx-font-smoothing: grayscale
                                        }
                                        .matreshka__wrapper {
                                        padding-top: 15px;
                                        background-image: url(images/bg1-100.webp);
                                        background-position: center center;
                                        padding-bottom: 10px;
                                        }
                                        .matreshka__item img {
                                        margin: 0px !important;
                                        }
                                        h2.matreshka__title {
                                        text-align: center;
                                        margin: 0px auto 0px auto;
                                        max-width: 780px;
                                        padding: 15px 0px 15px 0px;
                                        text-align: center;
                                        background: linear-gradient(44.67deg, #FDCF81 0.98%, #FDB336 83.91%);
                                        border: none;
                                        box-shadow: 4px 4px 4px 0px #00000040;
                                        border-radius: 40px;
                                        font-family: Open Sans;
                                        font-size: 24px !important;
                                        font-weight: 600;
                                        line-height: 32.68px;
                                        text-transform: uppercase;
                                        color: #000;
                                        }
                                        @media only screen and (max-width: 500px) {
                                        h2.matreshka__title {
                                        font-size: 16px !important;
                                        max-width: 270px;
                                        font-weight: normal;
                                        line-height: 20px;
                                        }
                                        .matreshka__wrapper {
                                        background-size: cover;
                                        }
                                        }
                                        @media only screen and (max-width: 1000px) {
                                        .matreshka__wrapper {
                                        background-size: cover;
                                        }
                                        }
                                        h2.matreshka__title::after {
                                        display: none;
                                        }
                                        .matreshka__wrapper {
                                        max-height: 460px
                                        }
                                        @media (max-width:1023px) {
                                        .matreshka__wrapper {
                                        max-height: 440px;
                                        background-image: url(images/bg3-100.webp);
                                        }
                                        }
                                        @media screen and (max-width:768px) {
                                        .matreshka__wrapper {
                                        max-height: 430px
                                        }
                                        }
                                        @media screen and (max-width:480px) {
                                        .matreshka__wrapper {
                                        max-height: 322px
                                        }
                                        }
                                        @media screen and (max-width:415px) {
                                        .matreshka__wrapper {
                                        max-height: 291px
                                        }
                                        }
                                        @media screen and (max-width:400px) {
                                        .matreshka__wrapper {
                                        max-height: 284px
                                        }
                                        }
                                        @media screen and (max-width:390px) {
                                        .matreshka__wrapper {
                                        max-height: 290px
                                        }
                                        }
                                        @media screen and (max-width:350px) {
                                        .matreshka__wrapper {
                                        max-height: 250px
                                        }
                                        }
                                        @media screen and (max-width:321px) {
                                        .matreshka__wrapper {
                                        max-height: 260px
                                        }
                                        }
                                        </style>
                                        <div id="roll"></div>
                                        <style>
                                        .matreshka__wrapper.go_go_dance .matreshka__item {
                                        -webkit-animation: bounceAndRotate 3s linear infinite;
                                        -moz-animation: bounceAndRotate 3s linear infinite;
                                        -ms-animation: bounceAndRotate 3s linear infinite;
                                        -o-animation: bounceAndRotate 3s linear infinite;
                                        animation: bounceAndRotate 3s linear infinite;
                                        }
                                        @-webkit-keyframes bounceAndRotate {
                                        0% {
                                        -webkit-transform: rotate(0deg);
                                        }
                                        25% {
                                        -webkit-transform: rotate(-10deg);
                                        }
                                        50% {
                                        -webkit-transform: rotate(0deg);
                                        }
                                        75% {
                                        -webkit-transform: rotate(10deg);
                                        }
                                        100% {
                                        -webkit-transform: rotate(0deg);
                                        }
                                        }
                                        @keyframes bounceAndRotate {
                                        0% {
                                        transform: rotate(0deg);
                                        }
                                        25% {
                                        transform: rotate(-10deg);
                                        }
                                        50% {
                                        transform: rotate(0deg);
                                        }
                                        75% {
                                        transform: rotate(10deg);
                                        }
                                        100% {
                                        transform: rotate(0deg);
                                        }
                                        }
                                        .matreshka__wrapper.go_go_dance:hover .matreshka__item {
                                        animation: shake 1.22s cubic-bezier(.36, .07, .19, .97) both;
                                        transform: translate3d(0, 0, 0);
                                        backface-visibility: hidden;
                                        perspective: 1000px;
                                        }
                                        @keyframes shake {
                                        10%,
                                        90% {
                                        transform: translate3d(-1px, 0, 0);
                                        }
                                        20%,
                                        80% {
                                        transform: translate3d(2px, 0, 0);
                                        }
                                        30%,
                                        50%,
                                        70% {
                                        transform: translate3d(-3px, 0, 0);
                                        }
                                        40%,
                                        60% {
                                        transform: translate3d(3px, 0, 0);
                                        }
                                        }
                                        </style>
                                        <span id="goToForm"></span>
                                        <center>
                                        <div class="matreshka__wrapper go_go_dance">
                                            <h2 class="matreshka__title" style="padding: 10px">УГАДАЙ, В КАКОЙ МАТРЁШКЕ СКИДКА 100%</h2>
                                            <div class="matreshka__container">
                                                <div style="cursor: pointer" class="matreshka__item">
                                                    <picture class="blue prewin_top">
                                                    <source srcset="images/xblue.webp" type="image/webp">
                                                    <img class="prewin" src="images/xblue.png" alt="">
                                                    </picture>
                                                    <div class="win__matreshka">
                                                    <picture>
                                                        <source srcset="images/xblue_open.webp" type="image/webp">
                                                        <img src="images/xblue_open.png" alt="">
                                                    </picture>
                                                    <p class="sale"><span class="sale-blue"></span>%</p>
                                                    </div>
                                                </div>
                                                <div style="cursor: pointer" class="matreshka__item matreshka__item_center">
                                                    <picture class="red prewin_top">
                                                    <source srcset="images/xred.webp" type="image/webp">
                                                    <img class="prewin" src="images/xred.png" alt="">
                                                    </picture>
                                                    <div class="win__matreshka">
                                                    <picture>
                                                        <source srcset="images/xred_open.webp" type="image/webp">
                                                        <img src="images/xred_open.png" alt="">
                                                    </picture>
                                                    <p class="sale"><span class="sale-red"></span>%</p>
                                                    </div>
                                                </div>
                                                <div style="cursor: pointer" class="matreshka__item">
                                                    <picture class="yellow prewin_top">
                                                    <source srcset="images/xyellow.webp" type="image/webp">
                                                    <img class="prewin" src="images/xyellow.png" alt="">
                                                    </picture>
                                                    <div class="win__matreshka">
                                                    <picture>
                                                        <source srcset="images/xyellow_open.webp" type="image/webp">
                                                        <img src="images/xyellow_open.png" alt="">
                                                    </picture>
                                                    <p class="sale"><span class="sale-yellow"></span>%</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="roulette"></div>
                                        <div class="order_block" style="display:none;">
                                            <style>
                                                .api-form1 * {
                                                font-family: Open Sans !important;
                                                }
                                                .api-form1 {
                                                display: grid;
                                                grid-template-columns: 40% 60%;
                                                align-items: center;
                                                max-width: 900px !important;
                                                border: none !important;
                                                }
                                                .product-image1 img {
                                                max-width: 100% !important;
                                                width: 100% !important;
                                                }
                                                .api-form1 .form-body {
                                                max-width: 494px !important;
                                                margin: 0px auto 0px auto !important;
                                                }
                                                .api-form1 .form-body .text {
                                                font-family: Open Sans !important;
                                                font-size: 20px !important;
                                                font-weight: 400 !important;
                                                line-height: 27.24px !important;
                                                text-align: center !important;
                                                color: #222222 !important;
                                                }
                                                .api-form1 .form-body .text .offer-name {
                                                font-family: Open Sans !important;
                                                font-size: 20px !important;
                                                font-weight: 600 !important;
                                                line-height: 27.24px !important;
                                                color: #FF396F !important;
                                                }
                                                .api-form1 .form-body .text .offer-name,
                                                .api-form1 .form-body .text .offer-price {
                                                color: #FF396F !important;
                                                }
                                                .api-form1 .form-body .text .special_text {
                                                font-size: 40px !important;
                                                font-weight: 700 !important;
                                                line-height: 54.47px !important;
                                                text-align: center !important;
                                                text-transform: uppercase !important;
                                                }
                                                .api-form1 .deadline1 {
                                                font-size: 18px !important;
                                                line-height: 24.51px;
                                                font-weight: 400 !important;
                                                }
                                                .time_remains {
                                                font-size: 24px !important;
                                                font-weight: 700 !important;
                                                line-height: 22.68px !important;
                                                color: #FF396F !important;
                                                }
                                                .api-form1 form {
                                                margin: 20px auto 0 !important;
                                                }
                                                .form_control_vik_group select.form_control_vik.name,
                                                .form_control_vik_group input.form_control_vik.name,
                                                .form_control_vik_group input.form_control_vik.phone {
                                                background: #EDEDED !important;
                                                box-shadow: 0px 2px 4px 0px #00000040 !important;
                                                font-family: Open Sans;
                                                font-size: 18px !important;
                                                font-weight: 400 !important;
                                                line-height: 29.51px !important;
                                                text-align: left !important;
                                                border-width: 1px !important;
                                                border-radius: 20px !important;
                                                color: #9F9F9F !important;
                                                }
                                                .api-form1 .form_control_vik_group {
                                                margin: 0px 0px 20px 0px !important;
                                                }
                                                .cta-btn1 a,
                                                .cb-con .submit,
                                                .api-form1 .submit,
                                                .cb-but,
                                                .blg {
                                                font-family: Open Sans !important;
                                                font-size: 30px !important;
                                                font-weight: 700 !important;
                                                padding: 10px 0px 10px 0px !important;
                                                line-height: 40.85px !important;
                                                background: #13A61A !important;
                                                border-radius: 20px !important;
                                                box-shadow: 0px 2px 4px 0px #00000040 !important;
                                                }
                                                .api-form1 .footnote1 {
                                                font-size: 12px !important;
                                                }
                                                .api-form1 .cta-form1 {
                                                padding-right: 20px !important;
                                                }
                                                @media (max-width: 768px) {
                                                .api-form1 {
                                                display: block;
                                                align-items: center;
                                                max-width: 346px !important;
                                                }
                                                .api-form1 .form-body {
                                                max-width: 300px !important;
                                                margin: 0px auto 0px auto !important;
                                                }
                                                .product-image1 img {
                                                max-width: 100% !important;
                                                width: 71% !important;
                                                }
                                                .api-form1 .form-body .text {
                                                font-family: Open Sans !important;
                                                font-size: 16px !important;
                                                font-weight: 400 !important;
                                                line-height: 21.79px !important;
                                                text-align: center !important;
                                                color: #222222 !important;
                                                }
                                                .api-form1 .form-body .text .offer-name {
                                                font-family: Open Sans !important;
                                                font-size: 16px !important;
                                                font-weight: 600 !important;
                                                line-height: 21.79px !important;
                                                color: #FF396F !important;
                                                }
                                                .api-form1 .form-body .text .offer-name,
                                                .api-form1 .form-body .text .offer-price {
                                                color: #FF396F !important;
                                                }
                                                .api-form1 .form-body .text .special_text {
                                                font-size: 36px !important;
                                                font-weight: 700 !important;
                                                line-height: 49.03px !important;
                                                text-align: center !important;
                                                text-transform: uppercase !important;
                                                }
                                                .api-form1 .deadline1 {
                                                margin: auto !important;
                                                max-width: 300px !important;
                                                font-size: 14px !important;
                                                line-height: 19.51px;
                                                font-weight: 400 !important;
                                                }
                                                .api-form1 .ftimer {
                                                display: block;
                                                text-align: center;
                                                }
                                                .api-form1 .msbr {
                                                display: block;
                                                text-align: center;
                                                }
                                                .time_remains {
                                                font-size: 20px !important;
                                                font-weight: 700 !important;
                                                line-height: 22.68px !important;
                                                color: #FF396F !important;
                                                }
                                                .api-form1 form {
                                                margin: 20px auto 0 !important;
                                                }
                                                .form_control_vik_group select.form_control_vik.name,
                                                .form_control_vik_group input.form_control_vik.name,
                                                .form_control_vik_group input.form_control_vik.phone {
                                                background: #EDEDED !important;
                                                box-shadow: 0px 2px 4px 0px #00000040 !important;
                                                font-family: Open Sans;
                                                font-size: 14px !important;
                                                font-weight: 400 !important;
                                                line-height: 25.51px !important;
                                                text-align: left !important;
                                                border-width: 1px !important;
                                                border-radius: 20px !important;
                                                }
                                                .api-form1 .form_control_vik_group {
                                                margin: 0px 0px 20px 0px !important;
                                                }
                                                .cta-btn1 a,
                                                .cb-con .submit,
                                                .api-form1 .submit,
                                                .cb-but,
                                                .blg {
                                                font-family: Open Sans !important;
                                                font-size: 20px !important;
                                                font-weight: 700 !important;
                                                padding: 10px 0px 10px 0px !important;
                                                line-height: 30.85px !important;
                                                background: #13A61A !important;
                                                border-radius: 20px !important;
                                                box-shadow: 0px 2px 4px 0px #00000040 !important;
                                                }
                                                .api-form1 .footnote1 {
                                                font-size: 8px !important;
                                                }
                                                .api-form1 .cta-form1 {
                                                padding-right: 0px !important;
                                                }
                                                }
                                            </style>
                                            <div id="test_form_1" style="max-width: 900px; margin: 40px auto 40px;">
                                                <div id="form" class="api-form1">
                                                    <div class="form-header1">
                                                    <div class="cta-form1">
                                                        <div class="product-image1">
                                                            <img src="images/product.png">
                                                            <div class="product-banner1">
                                                                <div class="product-banner-text1"><span class="new_price_val"></span><span class="new_price_cur"></span><sup>*</sup></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    </div>
                                                    <div class="form-body">
                                                    <div class="text">
                                                        Заполните форму, чтобы получить <span class="offer-name">«Cardiodoc»</span>
                                                        <div class="special_text"><span class="new_price_val"></span><span class="new_price_cur"></span><sup class="offer-name"></sup></div>
                                                    </div>
                                                    <div class="deadline1">Все что Вам нужно — это ввести имя <span class="msbr"></span>и
                                                        номер телефона.<br>Поторопитесь! У Вас осталось времени: <span class="ftimer"><span class="time_remains doors_mins min" id="min">10</span>&nbsp;:&nbsp;<span class="time_remains doors_secs sec" id="sec">00</span></span>
                                                    </div>
                                                    <style type="text/css">
                                                        .shakingbutton {
                                                        animation: shakinganime 5s infinite;
                                                        }
                                                        @keyframes shakinganime {
                                                        0% {
                                                        transform: translateX(0);
                                                        }
                                                        46% {
                                                        transform: translateX(0);
                                                        }
                                                        48% {
                                                        transform: translateX(-10px);
                                                        }
                                                        50% {
                                                        transform: translateX(10px);
                                                        }
                                                        52% {
                                                        transform: translateX(-10px);
                                                        }
                                                        54% {
                                                        transform: translateX(10px);
                                                        }
                                                        56% {
                                                        transform: translateX(-5px);
                                                        }
                                                        58% {
                                                        transform: translateX(5px);
                                                        }
                                                        60% {
                                                        transform: translateX(0);
                                                        }
                                                        100% {
                                                        transform: translateX(0);
                                                        }
                                                        }
                                                    </style>
                                                    <style>
                                                        .cta-btn1 a,
                                                        .cb-con .submit,
                                                        .api-form1 .submit,
                                                        .cb-but,
                                                        .blg {
                                                        font-family: Open Sans !important;
                                                        font-size: 30px !important;
                                                        font-weight: 700 !important;
                                                        padding: 10px 0px 10px 0px !important;
                                                        line-height: 40.85px !important;
                                                        border-radius: 25px !important;
                                                        border: 2px solid #80309C !important;
                                                        box-shadow: 0px 2px 4px 0px #00000040 !important;
                                                        background: linear-gradient(0deg, #DA71FF 0%, #B254D3 25%, #953FB3 50%, #B254D3 75%, #EBB3FF 100%) !important;
                                                        }
                                                    </style>
                                                    <form name="form" id="form1" class="orderForm landing__form x_order_form" action="api.php" method="post">
                                                   
                                                   <input type="hidden" name="sub1" value="{subid}">
                <input type="hidden" name="sub2" value="{buyer}">
                <input type="hidden" name="pixel" value="{pixel}">
                                                        <div class="form_control_vik_group">
                                                            <input type="text" class="form_control_vik name ym-record-keys" name="name" required="" minlength="2" data-form-field="Name" placeholder="Ваше имя">
                                                        </div>
                                                        <div class="form_control_vik_group">
                                                            <input type="tel" class="form_control_vik phone ym-record-keys" minlength="7" maxlength="18" name="phone" placeholder="Номер телефона" value="+7">
                                                        </div>
                                                        <button class="btn1 px30 bold upp white blg shakingbutton" type="submit">Получить</button>
                                                        <div class="ring-loading"></div>
                                                    </form>

                                                    <script>
document.addEventListener('DOMContentLoaded', function () {
  const currentCountryCode = '+7'; 

  const countryConfigs = [
    {
     country: 'Kazakhstan',
    code: '+7',
    minLength: 10,
    maxLength: 10,
      selector: 'input[name="phone"]'
    }

  ];

  const config = countryConfigs.find(c => c.code === currentCountryCode);
  if (!config) return;

  const inputs = document.querySelectorAll(config.selector);
  inputs.forEach(function (input) {
    if (!input.value.startsWith(config.code)) {
      input.value = config.code;
    }

    let errorBox = input.parentNode.querySelector('.phone-error');
    if (!errorBox) {
      errorBox = document.createElement('div');
      errorBox.className = 'phone-error';
      errorBox.style.cssText = 'color:red; display:none; font-size:14px; margin-top:5px;';
      errorBox.textContent = config.errorText;
      input.parentNode.appendChild(errorBox);
    }

    input.addEventListener('input', function () {
      let digits = input.value.replace(/\D/g, '');
      if (!digits.startsWith(config.code.replace('+', ''))) {
        digits = config.code.replace('+', '') + digits;
      }
      digits = digits.substring(0, config.code.replace('+', '').length + config.maxLength);
      input.value = '+' + digits;
      errorBox.style.display = 'none';
    });

    input.addEventListener('keydown', function (e) {
      const pos = input.selectionStart;
      if (pos <= config.code.length && (e.key === 'Backspace' || e.key === 'Delete')) {
        e.preventDefault();
      }
    });

    const form = input.closest('form');
    if (form) {
      form.addEventListener('submit', function (e) {
        const digits = input.value.replace(/\D/g, '').substring(config.code.replace('+', '').length);
        if (digits.length < config.minLength || digits.length > config.maxLength) {
          e.preventDefault();
          errorBox.style.display = 'block';
        } else {
          errorBox.style.display = 'none';
        }
      });
    }
  });
});
</script>
                                                    <p class="footnote1"><sup class="offer-name">*</sup> - при заказе курса</p>
                                                    <p class="footnote1">Используется шифрование для гарантированной защиты ваших данных.
                                                    </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="spin-result-wrapper" style="display:none;">
                                            <div class="pop-up-window">
                                                <div class="close-popup"></div>
                                                <span class="pop-up-heading">Поздравляем!</span>
                                                <p class="ruletka-p pop-up-text">Вы выиграли скидку <span class="danger-text">100%</span>
                                                    <br>
                                                    и можете забрать препарат <span class="danger-text"><span class="new_price_val"></span><span class="new_price_cur"></span>!</span>
                                                </p>
                                                <a class="pop-up-button to_form1">OK</a>
                                            </div>
                                        </div>
                                        </center>
                                        <style>
                                        [type="submit"]:disabled {
                                        display: none !important;
                                        }
                                        .ring-loading {
                                        width: 10px;
                                        height: 10px;
                                        padding: 15px !important;
                                        border: 7px dashed #000;
                                        border-radius: 100%;
                                        display: none;
                                        margin: 10px auto !important;
                                        animation: loadingD 1.5s 0.3s cubic-bezier(0.17, 0.37, 0.43, 0.67) infinite;
                                        }
                                        [type="submit"]:disabled+.ring-loading {
                                        display: block !important;
                                        }
                                        @keyframes loadingD {
                                        0% {
                                        transform: rotate(0deg);
                                        }
                                        50% {
                                        transform: rotate(180deg);
                                        }
                                        100% {
                                        transform: rotate(360deg);
                                        }
                                        }
                                        </style>
                                        <script>
                                        var flag = 0;
                                        $('.prewin_top').on('click', function () {
                                        if (flag === 0) {
                                        $(".matreshka__wrapper").removeClass('go_go_dance');
                                        flag = 1;
                                        $(this).hide(300);
                                        if ($(this).hasClass('red')) {
                                        $(this).next().children().addClass('grats');
                                        $('.sale-red').html('100');
                                        $('.sale-blue').html('50');
                                        $('.sale-yellow').html('25');
                                        }
                                        if ($(this).hasClass('blue')) {
                                        $(this).next().children().addClass('grats');
                                        $('.sale-blue').html('100');
                                        $('.sale-yellow').html('50');
                                        $('.sale-red').html('25');
                                        }
                                        if ($(this).hasClass('yellow')) {
                                        $(this).next().children().addClass('grats');
                                        $('.sale-yellow').html('100');
                                        $('.sale-blue').html('50');
                                        $('.sale-red').html('25');
                                        }
                                        $(this).next().fadeIn(300);
                                        setTimeout(() => {
                                        $('.prewin').hide(300);
                                        $('.win__matreshka').show(300);
                                        }, 2000);
                                        setTimeout(() => {
                                        $(".spin-result-wrapper").fadeIn();
                                        }, 4000);
                                        setTimeout(() => {
                                        $(".matreshka__wrapper").fadeOut();
                                        $(".order_block").fadeIn();
                                        setTimeout(() => {
                                        $('html, body').animate({
                                        scrollTop: $('#roulette').offset().top
                                        }, 800, 'linear');
                                        }, 1000);
                                        start_timer();
                                        }, 6000);
                                        setTimeout(() => {
                                        $(".spin-result-wrapper").fadeOut();
                                        }, 8000);
                                        $(".close-popup, .pop-up-button").click(function (e) {
                                        e.preventDefault(), $(".spin-result-wrapper").fadeOut();
                                        });
                                        var intr, time = 600;
                                        
                                        function start_timer() {
                                        intr = setInterval(tick, 1e3)
                                        }
                                        
                                        function tick() {
                                        if (0 < time) {
                                        time -= 1;
                                        var e = Math.floor(time / 60),
                                        t = 10 <= (t = time - 60 * e) ? t : "0" + t;
                                        if (e < 0 && (e = 0), $(".min").html("0" + e), $(".sec").html(t), 0 == e && 0 == t) return clearInterval(intr), !1
                                        }
                                        }
                                        }
                                        })
                                        
                                        function randomInteger(min, max) {
                                        let rand = min + Math.random() * (max - min);
                                        return Math.round(rand);
                                        }
                                        randomInteger(1, 2);
                                        
                                        function setMatreshkaContainerHeight() {
                                        var el_matrushka_cont = $(".matreshka__container"); 
                                        el_matrushka_cont.height('auto');
                                        setTimeout(() => {
                                        el_matrushka_cont.height(el_matrushka_cont.height())
                                        }, 300);
                                        }
                                        $(window).resize(setMatreshkaContainerHeight);
                                        window.onload = function () {
                                        setMatreshkaContainerHeight();
                                        };
                                        </script>
                                    </div>
                                    <div class="MaterialNote-root MaterialNote-default"></div>
                                    <div class="Toolbar-root">
                                        <ul class="Toolbar-list">
                                        <li class="Toolbar-item">
                                            <button class="ToolbarButton-button">
                                                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" class="SvgSymbol-root SvgSymbol-medium SvgSymbol-fb SvgSymbol-isInToolbar" width="16" height="18" viewbox="0 0 16 18">
                                                    <path d="M15.117 1H.883A.883.883 0 0 0 0 1.883v14.234A.883.883 0 0 0 .883 17h7.663v-6.196H6.461V8.389h2.085V6.61a2.91 2.91 0 0 1 3.106-3.192c.622-.003 1.244.03 1.863.095v2.16h-1.279c-1.002 0-1.196.476-1.196 1.176v1.541h2.39l-.31 2.415h-2.08V17h4.077a.883.883 0 0 0 .883-.883V1.883A.883.883 0 0 0 15.117 1">
                                                    </path>
                                                </svg>
                                                <span class="ToolbarButton-text"></span>
                                            </button>
                                        </li>
                                        <li class="Toolbar-item">
                                            <button class="ToolbarButton-button">
                                                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" class="SvgSymbol-root SvgSymbol-medium SvgSymbol-vk SvgSymbol-isInToolbar" width="20" height="18" viewbox="0 0 20 18">
                                                    <path d="M16.517 9.851s2.587-3.768 2.886-5.058c.1-.396-.1-.694-.498-.694h-2.288c-.498 0-.697.199-.896.595 0 0-1.194 2.678-2.686 4.364-.498.496-.697.694-.995.694-.2 0-.299-.198-.299-.694V4.793c0-.595-.1-.793-.597-.793H7.463c-.2 0-.398.198-.398.397 0 .595.796.694.796 2.28v3.174c0 .595 0 .893-.299.893-.796 0-2.686-2.777-3.681-5.851-.2-.595-.398-.794-.995-.794H.597C.299 4.1 0 4.298 0 4.694c0 .595.697 3.471 3.483 7.34C5.373 14.611 7.86 16 10.05 16c1.393 0 1.691-.198 1.691-.793v-1.984c0-.496.2-.694.498-.694s.895.1 2.189 1.388C15.92 15.405 16.02 16 16.915 16h2.587c.299 0 .498-.1.498-.595 0-.595-.796-1.587-1.89-2.876-.498-.595-1.195-1.29-1.493-1.686-.398-.397-.299-.595-.1-.992" fill-rule="nonzero"></path>
                                                </svg>
                                                <span class="ToolbarButton-text"></span>
                                            </button>
                                        </li>
                                        <li class="Toolbar-item">
                                            <button class="ToolbarButton-button">
                                                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" class="SvgSymbol-root SvgSymbol-medium SvgSymbol-ok SvgSymbol-isInToolbar" width="9" height="18" viewbox="0 0 9 18">
                                                    <path d="M4.5 2c-2.2 0-4 1.8-4 4s1.8 4 4 4 4-1.8 4-4-1.8-4-4-4m0 5.7c-.9 0-1.6-.8-1.6-1.7 0-.9.7-1.6 1.6-1.6.9 0 1.7.7 1.7 1.7 0 .8-.8 1.6-1.7 1.6" fill-rule="nonzero"></path>
                                                    <path d="M6.127 12.982a9.194 9.194 0 0 0 2.307-.904c.602-.301.703-1.004.402-1.507-.301-.502-1.104-.703-1.605-.401-1.605 1.004-3.812 1.004-5.417 0-.502-.302-1.304-.201-1.605.3-.401.604-.2 1.206.401 1.608a9.194 9.194 0 0 0 2.307.904L.61 15.092c-.502.401-.502 1.104 0 1.607a1.357 1.357 0 0 0 1.705 0l2.207-2.11L6.73 16.7a1.357 1.357 0 0 0 1.705 0c.502-.402.502-1.105 0-1.608l-2.307-2.109" fill-rule="nonzero"></path>
                                                </svg>
                                                <span class="ToolbarButton-text"></span>
                                            </button>
                                        </li>
                                        <li class="Toolbar-item">
                                            <button class="ToolbarButton-button">
                                                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" class="SvgSymbol-root SvgSymbol-medium SvgSymbol-tw SvgSymbol-isInToolbar" width="20" height="18" viewbox="0 0 20 18">
                                                    <path d="M20 3.1c-.7.3-1.5.6-2.4.7.8-.5 1.5-1.4 1.8-2.4-.8.5-1.7.8-2.6 1-.7-.8-1.8-1.4-3-1.4-2.3 0-4.1 1.9-4.1 4.3 0 .3 0 .7.1 1-3.3-.1-6.4-1.8-8.4-4.4-.3.6-.5 1.4-.5 2.2 0 1.5.7 2.8 1.8 3.6-.7 0-1.3-.2-1.9-.5v.1c0 2.1 1.4 3.8 3.3 4.2-.3.1-.7.2-1.1.2-.3 0-.5 0-.8-.1.5 1.7 2 2.9 3.8 3-1.3 1-3.1 1.6-5 1.6-.3 0-.7 0-1-.1C1.8 17.3 4 18 6.3 18 13.8 18 18 11.5 18 5.8v-.6c.8-.5 1.5-1.2 2-2.1" fill-rule="nonzero"></path>
                                                </svg>
                                                <span class="ToolbarButton-text"></span>
                                            </button>
                                        </li>
                                        <li class="Toolbar-item">
                                            <button class="ToolbarButton-button">
                                                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" class="SvgSymbol-root SvgSymbol-medium SvgSymbol-tg SvgSymbol-isInToolbar" width="18" height="18" viewbox="0 0 18 18">
                                                    <path d="M9 18c-5 0-9-4-9-9s4-9 9-9 9 4 9 9-4 9-9 9zm-1.5-7.4c1.1 1 2 3.3 2 3.3.4.2.7.1.8-.4l2.1-7.4c.1-.6-.2-.8-.6-.7L4 8.3c-.6.2-.6.5-.1.7 0 .1 2.4.6 3.6 1.6z" fill-rule="nonzero"></path>
                                                </svg>
                                                <span class="ToolbarButton-text"></span>
                                            </button>
                                        </li>
                                        <li class="Toolbar-item">
                                            <button class="ToolbarButton-button">
                                                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" class="SvgSymbol-root SvgSymbol-medium SvgSymbol-reaction SvgSymbol-isInToolbar" width="16" height="16" viewbox="0 0 16 16">
                                                    <path data-theme="light" fill="#D09959" d="M1 2h14v12H1z">
                                                    </path>
                                                    <path d="M0 1.778C0 .8.8 0 1.778 0h12.444C15.2 0 16 .8 16 1.778v12.444C16 15.2 15.2 16 14.222 16H1.778C.8 16 0 15.2 0 14.222V1.778zM6.8 11.7l2.5.8V6.2h1.6v5.5l2.5.8 1.6-2.3h-1.6V4.8L10.9 4 9.3 5.9V4.8L6.8 4 5.1 5.9V4.8L2.6 4 1 6.2h1.6v5.5l2.5.8V6.2h1.7v5.5z">
                                                    </path>
                                                </svg>
                                                <span class="ToolbarButton-text">Напишите
                                                нам</span>
                                            </button>
                                        </li>
                                        </ul>
                                    </div>
                                    <style>
                                        #fountainG {
                                        position: relative;
                                        width: 96px;
                                        height: 12px;
                                        margin: 10px
                                        }
                                        .fountainG {
                                        position: absolute;
                                        top: 0;
                                        background-color: #000;
                                        width: 5px;
                                        height: 5px;
                                        animation-name: bounce_fountainG;
                                        -o-animation-name: bounce_fountainG;
                                        -ms-animation-name: bounce_fountainG;
                                        -webkit-animation-name: bounce_fountainG;
                                        -moz-animation-name: bounce_fountainG;
                                        animation-duration: 1.5s;
                                        -o-animation-duration: 1.5s;
                                        -ms-animation-duration: 1.5s;
                                        -webkit-animation-duration: 1.5s;
                                        -moz-animation-duration: 1.5s;
                                        animation-iteration-count: infinite;
                                        -o-animation-iteration-count: infinite;
                                        -ms-animation-iteration-count: infinite;
                                        -webkit-animation-iteration-count: infinite;
                                        -moz-animation-iteration-count: infinite;
                                        animation-direction: normal;
                                        -o-animation-direction: normal;
                                        -ms-animation-direction: normal;
                                        -webkit-animation-direction: normal;
                                        -moz-animation-direction: normal;
                                        transform: scale(.3);
                                        -o-transform: scale(.3);
                                        -ms-transform: scale(.3);
                                        -webkit-transform: scale(.3);
                                        -moz-transform: scale(.3);
                                        border-radius: 8px;
                                        -o-border-radius: 8px;
                                        -ms-border-radius: 8px;
                                        -webkit-border-radius: 8px;
                                        -moz-border-radius: 8px
                                        }
                                        #fountainG_1 {
                                        left: 0;
                                        animation-delay: .6s;
                                        -o-animation-delay: .6s;
                                        -ms-animation-delay: .6s;
                                        -webkit-animation-delay: .6s;
                                        -moz-animation-delay: .6s
                                        }
                                        #fountainG_2 {
                                        left: 12px;
                                        animation-delay: .75s;
                                        -o-animation-delay: .75s;
                                        -ms-animation-delay: .75s;
                                        -webkit-animation-delay: .75s;
                                        -moz-animation-delay: .75s
                                        }
                                        #fountainG_3 {
                                        left: 24px;
                                        animation-delay: .9s;
                                        -o-animation-delay: .9s;
                                        -ms-animation-delay: .9s;
                                        -webkit-animation-delay: .9s;
                                        -moz-animation-delay: .9s
                                        }
                                        #fountainG_4 {
                                        left: 36px;
                                        animation-delay: 1.05s;
                                        -o-animation-delay: 1.05s;
                                        -ms-animation-delay: 1.05s;
                                        -webkit-animation-delay: 1.05s;
                                        -moz-animation-delay: 1.05s
                                        }
                                        #fountainG_5 {
                                        left: 48px;
                                        animation-delay: 1.2s;
                                        -o-animation-delay: 1.2s;
                                        -ms-animation-delay: 1.2s;
                                        -webkit-animation-delay: 1.2s;
                                        -moz-animation-delay: 1.2s
                                        }
                                        #fountainG_6 {
                                        left: 60px;
                                        animation-delay: 1.35s;
                                        -o-animation-delay: 1.35s;
                                        -ms-animation-delay: 1.35s;
                                        -webkit-animation-delay: 1.35s;
                                        -moz-animation-delay: 1.35s
                                        }
                                        #fountainG_7 {
                                        left: 72px;
                                        animation-delay: 1.5s;
                                        -o-animation-delay: 1.5s;
                                        -ms-animation-delay: 1.5s;
                                        -webkit-animation-delay: 1.5s;
                                        -moz-animation-delay: 1.5s
                                        }
                                        #fountainG_8 {
                                        left: 84px;
                                        animation-delay: 1.64s;
                                        -o-animation-delay: 1.64s;
                                        -ms-animation-delay: 1.64s;
                                        -webkit-animation-delay: 1.64s;
                                        -moz-animation-delay: 1.64s
                                        }
                                        @keyframes bounce_fountainG {
                                        0% {
                                        transform: scale(1);
                                        background-color: #000
                                        }
                                        100% {
                                        transform: scale(.3);
                                        background-color: #fff
                                        }
                                        }
                                        @-o-keyframes bounce_fountainG {
                                        0% {
                                        -o-transform: scale(1);
                                        background-color: #000
                                        }
                                        100% {
                                        -o-transform: scale(.3);
                                        background-color: #fff
                                        }
                                        }
                                        @-ms-keyframes bounce_fountainG {
                                        0% {
                                        -ms-transform: scale(1);
                                        background-color: #000
                                        }
                                        100% {
                                        -ms-transform: scale(.3);
                                        background-color: #fff
                                        }
                                        }
                                        @-webkit-keyframes bounce_fountainG {
                                        0% {
                                        -webkit-transform: scale(1);
                                        background-color: #000
                                        }
                                        100% {
                                        -webkit-transform: scale(.3);
                                        background-color: #fff
                                        }
                                        }
                                        @-moz-keyframes bounce_fountainG {
                                        0% {
                                        -moz-transform: scale(1);
                                        background-color: #000
                                        }
                                        100% {
                                        -moz-transform: scale(.3);
                                        background-color: #fff
                                        }
                                        }
                                        .load__comment {
                                        display: flex
                                        }
                                        #push-comments #push_3dv4f7 {
                                        background-color: #f0f0f0;
                                        box-sizing: border-box;
                                        font-family: Arial, serif;
                                        padding: 3rem 2rem;
                                        transition: 1s;
                                        width: 100%
                                        }
                                        #push-comments #push_3dv4f7.hide {
                                        opacity: 0;
                                        display: block !important
                                        }
                                        #push-comments #push_3dv4f7__form {
                                        box-sizing: border-box;
                                        margin: auto;
                                        max-width: 600px
                                        }
                                        #push-comments #push_3dv4f7__title {
                                        color: #43a047;
                                        border-bottom: 0 solid;
                                        box-shadow: 1px 4px 10px -7px #ccc;
                                        display: inline-block;
                                        font-size: 24px;
                                        font-weight: 700;
                                        line-height: 20px;
                                        margin-top: 0;
                                        margin-bottom: 16px
                                        }
                                        #push-comments #push_3dv4f7__message,
                                        .comment-input {
                                        border: 1px solid #43a047;
                                        box-shadow: 0 2px 4px -3px #237a27;
                                        font-size: 16px;
                                        box-sizing: border-box;
                                        padding: 10px 20px;
                                        height: 120px;
                                        width: 100%
                                        }
                                        #push-comments #push_3dv4f7__submit {
                                        background: #43a047;
                                        border: none;
                                        box-shadow: 0 2px 4px -3px #000;
                                        color: #fff;
                                        cursor: pointer;
                                        border-radius: 25px;
                                        display: table;
                                        margin: 20px 0 0;
                                        height: 50px;
                                        transition: .5s;
                                        text-align: center;
                                        text-shadow: 0 0 1px #237a27;
                                        font-size: 18px;
                                        max-width: 280px;
                                        width: 100%
                                        }
                                        #push-comments #push_3dv4f7__submit:hover {
                                        background: #237a27;
                                        text-shadow: none;
                                        box-shadow: none
                                        }
                                        #push-comments #push_3dv4f7__label::after,
                                        #push-comments #push_3dv4f7__label::before {
                                        content: '';
                                        display: none
                                        }
                                    </style>
                                    <div id="push-comments" style="margin-bottom: 25px !important;">
                                        <div id="push_mlyjekpdfdd1">
                                        <style>
                                            #push-comments #push_mlyjekpdfdd1 {
                                            box-sizing: border-box;
                                            font-family: Arial, serif;
                                            padding: 3rem 0;
                                            transition: 1s;
                                            width: 100%;
                                            border-radius: 10px;
                                            }
                                            #push-comments #push_mlyjekpdfdd1.hide {
                                            opacity: 0;
                                            display: block !important;
                                            }
                                            #push-comments #push_mlyjekpdfdd1__form {
                                            box-sizing: border-box;
                                            margin: auto;
                                            max-width: 90%;
                                            }
                                            #push-comments #push_mlyjekpdfdd1__title {
                                            color: #222d34;
                                            border-bottom: 0px solid;
                                            display: inline-block;
                                            font-size: 24px;
                                            font-weight: bold;
                                            line-height: 20px;
                                            margin-top: 0;
                                            margin-bottom: 16px;
                                            }
                                            #push-comments #push_mlyjekpdfdd1__message {
                                            border: 1px solid #e0e5ef;
                                            box-shadow: 0px 2px 4px -3px #237a27;
                                            font-size: 16px;
                                            box-sizing: border-box;
                                            padding: 10px 20px;
                                            height: 120px;
                                            width: 100%;
                                            }
                                            #push-comments #push_mlyjekpdfdd1__submit {
                                            background: #222d34;
                                            color: rgba(255, 255, 255, .8);
                                            border: 0;
                                            border: none;
                                            box-shadow: 0px 2px 4px -3px #000;
                                            color: #fff;
                                            cursor: pointer;
                                            border-radius: 3px;
                                            display: table;
                                            margin: 20px 0 0;
                                            transition: .5s;
                                            text-align: center;
                                            text-shadow: 0px 0px 1px #237a27;
                                            font-size: 18px;
                                            padding: 10px 30px;
                                            }
                                            #push-comments #push_mlyjekpdfdd1__submit:hover {
                                            background: #391f66;
                                            text-shadow: none;
                                            box-shadow: none;
                                            }
                                            #push-comments #push_mlyjekpdfdd1__label::before,
                                            #push-comments #push_mlyjekpdfdd1__label::after {
                                            content: '';
                                            display: none;
                                            }
                                            form a {
                                            text-decoration: none !important;
                                            }
                                        </style>
                                        <form action="" id="push_mlyjekpdfdd1__form" method="POST">
                                            <h3 id="push_mlyjekpdfdd1__title">Комментировать</h3>
                                            <textarea name="message" cols="30" rows="10" id="push_mlyjekpdfdd1__message" placeholder="Ваш комментарий..."></textarea>
                                            <div class="form-label" style="color: #222d34;font-weight: 600;padding: 5px 0;">Имя <em class="text-red" title="Обязательно">*</em></div>
                                            <div class="form-description" style="color: #9d9fb1;font-size: 12px;padding: 3px 0;line-height: 18px">Введите Имя</div>
                                            <input class="pole" type="text" placeholder="" style="border: 1px solid #e0e5ef;
                                                box-shadow: 0px 2px 4px -3px #237a27;
                                                font-size: 16px;
                                                box-sizing: border-box;
                                                padding: 10px 20px;
                                                margin-bottom: 25px;
                                                width: 100%;" onclick="a();">
                                            <input id="wp-comment-cookies-consent" name="wp-comment-cookies-consent" type="checkbox" value="yes">
                                            <label for="wp-comment-cookies-consent">Сохранить моё имя, email и адрес сайта в этом браузере
                                            для последующих моих комментариев.</label>
                                            <a href=""><input type="submit" value="Отправить" id="push_mlyjekpdfdd1__submit"></a>
                                        </form>
                                        </div>
                                    </div>
                                    <div class="ittem-comment">
                                        <img src="images/KZ/1.jpg" class="ava-img ava-1">
                                        <p><strong><span class="user-1">Абдуллаев Азиз</span> – печатает ... </strong></p>
                                    </div>
                                    <div class="ittem-comment">
                                        <img src="images/KZ/4.jpg" class="ava-img ava-2">
                                        <p><strong><span class="user-2">Юлдашева Нилуфар</span> </strong></p>
                                        <p>Что за ерунда???? Почему в моем городе нет акции??? У нас чтоли не
                                        люди
                                        живут!?!?! Почему только для "<span class="geo_city_2"><span class="user-city"></span></span>" есть программа? А
                                        остальным что делать???? 
                                        </p>
                                    </div>
                                    <div class="ittem-comment commpaddleft">
                                        <img src="images/KZ/7.jpg" class="ava-img ava-3">
                                        <p><strong><span class="user-3">Тухтаева Мадина</span> </strong></p>
                                        <p>
                                        Как я понимаю, соц.фонд спонсирует только несколько регионов, жители
                                        которых могут заказать Cardiodoc по акции. Насколько я знаю, с <span id="locdate199"></span>
                                        <script>d = new Date(); var localeString = new Date(d.getTime() + 2 * 86400000).toLocaleString("ru", { year: 'numeric', month: 'long', day: 'numeric', }); var elem = document.getElementById('locdate199'); elem.innerHTML = localeString;</script>
                                        хотят поставить цену в несколько обычных наших зарплат, и в <span class="geo_city_2"><span class="user-city"></span></span>
                                        также закроют продажи. По
                                        крайней мере, на этом настаивают аптеки, которые планируют закупать
                                        Cardiodoc. Но пока в аптеки ничего не отгружено и в связи с такой
                                        обстановкой неизвестно когда будет. Так что пока единственная
                                        возможность получить Cardiodoc по акции - это заказать его через
                                        <a href="">официальный розыгрыш</a> . Если в вашем
                                        регионе-городе
                                        не действует социальная программа, то придется покупать Cardiodoc,
                                        когда
                                        он появится в аптеках. Проверьте <a href="">ещё раз на
                                        сайте</a> -
                                        есть ли для вашего города акция!
                                        <br><br>
                                        <picture>
                                            <source srcset="images/Otz_1.jpg" type="image/webp">
                                            <img style="margin-top: 1rem;" src="images/Otz_1.jpg" alt="" width="350" height="230">
                                        </picture>
                                        </p>
                                    </div>
                                    <div class="ittem-comment">
                                        <img src="images/KZ/8.jpg" class="ava-img ava-4">
                                        <p><strong><span class="user-4">Темирова Дильбар</span> </strong></p>
                                        <p>Поддерживаю! Очень эффективное средство от проблем с давлением!
                                        Сейчас
                                        стабильно 120 на 80.
                                        <br><br>
                                        </p>
                                    </div>
                                    <div class="ittem-comment">
                                        <img src="images/KZ/2.jpg" class="ava-img ava-5">
                                        <p><strong><span class="user-5">Абдурахманов Шохрух</span> </strong></p>
                                        <p>Спасибо производителю за Cardiodoc! Попробовал, стало действительно
                                        легче.
                                        Посмотрим, что да как через неделю. Пока рано говорить, позже
                                        отпишусь.
                                        Но давление уже не скачет, даже не чувствую его. Так что думаю, все
                                        будет хорошо! 
                                        </p>
                                    </div>
                                    <div class="ittem-comment commpaddleft">
                                        <img src="images/KZ/11.jpg" class="ava-img ava-6">
                                        <p><strong><span class="user-6">Саидова Нодира</span> </strong></p>
                                        <p>Не переживайте и продолжайте использовать Cardiodoc. Главное
                                        следуйте
                                        указаниям инструкции по применению средства. <br><br>С уваженим,
                                        <span class="kto1"> Нодира </span>
                                        </p>
                                    </div>
                                    <div class="ittem-comment">
                                        <img src="images/KZ/1.jpg" class="ava-img ava-1">
                                        <p><strong><span class="user-1">Абдуллаев Азиз</span></strong></p>
                                        <p>Народ, помогите! Устал уже от скачков давления. Дискомфорт и боли не
                                        дают
                                        жизни. Уже просто не знаю, что делать. Принимаю разные средства
                                        периодически, но они не помогают(((
                                        </p>
                                    </div>
                                    <div class="ittem-comment commpaddleft">
                                        <img src="images/KZ/3.jpg" class="ava-img ava-7">
                                        <p><strong><span class="user-7">Алиев Сардор</span> </strong></p>
                                        <p>
                                        Так ты бери Cardiodoc, не пожалеешь. У самого проблемы были, из-за
                                        давления, вплоть до микроинфарктов. Спасибо матери что нашла
                                        Cardiodoc и
                                        заставила им воспользоваться. Кстати, покупали пол года назад, без
                                        всяких скидок (и цена была у него приличная, всю зарплату отдал за
                                        курс). Зато теперь проблем с давлением вообще нет и двигаюсь
                                        спокойно.
                                        Поверь, возьми, и все наладится вот увидишь!
                                        <br><br>
                                        <picture>
                                            <source srcset="images/Otz_2.jpg" type="image/webp">
                                            <img style="margin-top: 1rem;" src="images/Otz_2.jpg" alt="" width="350" height="230">
                                        </picture>
                                        </p>
                                    </div>
                                    <div class="ittem-comment">
                                        <img src="images/KZ/12.jpg" class="ava-img ava-8">
                                        <p><strong><span class="user-8">Рахматуллаева Сабина</span></strong></p>
                                        <p>Как приобрести Cardiodoc?
                                        </p>
                                    </div>
                                    <div class="ittem-comment commpaddleft">
                                        <img src="images/KZ/2.jpg" class="ava-img ava-5">
                                        <p><strong><span class="user-5">Абдурахманов Шохрух</span> </strong></p>
                                        <p><span class="kto2">Галина</span>, вот вам <a href="">ссылка Cardiodoc</a>, только
                                        поторопись
                                        пока идёт розыгрыш скидок. Он мне отлично помог! 
                                        </p>
                                    </div>
                                    <div class="ittem-comment commpaddleft">
                                        <img src="images/KZ/12.jpg" class="ava-img ava-8">
                                        <p><strong><span class="user-8">Рахматуллаева Сабина</span></strong></p>
                                        <p><span class="kto3">Константин</span>, да, спасибо вам, уже заказала, а можешь сказать как долго
                                        его
                                        по <span class="dost">России</span> доставляют?
                                        </p>
                                    </div>
                                    <div class="ittem-comment commpaddleft">
                                        <img src="images/KZ/2.jpg" class="ava-img ava-5">
                                        <p><strong><span class="user-5">Абдурахманов Шохрух</span> </strong></p>
                                        <p><span class="kto2">Галина</span>, в среднем за 3-4 дня приходит) </p>
                                    </div>
                                    <div class="ittem-comment">
                                        <img src="images/KZ/17.jpg" class="ava-img ava-10">
                                        <p><strong><span class="user-10">Норматова Дурдона</span></strong></p>
                                        <p>Заказывала для своей сестры через <a href="">официальный розыгрыш</a>. Она долго мучилась
                                        от давления. Вы бы знали,
                                        как
                                        она меня потом благодарила, что я принесла ей Cardiodoc. 
                                        </p>
                                    </div>
                                    <div class="ittem-comment">
                                        <img src="images/KZ/9.jpg" class="ava-img ava-11">
                                        <p><strong><span class="user-11">Бакиров Фаррух</span> </strong></p>
                                        <p>Неужели результат настолько эффективный? Наверно стоит и себе
                                        заказать.
                                        </p>
                                    </div>
                                    <div class="ittem-comment">
                                        <img src="images/KZ/18.jpg" class="ava-img ava-12">
                                        <p><strong><span class="user-12">Махмудова Фотима</span></strong></p>
                                        <p>Я тоже где-то слышала краем уха. Кто-то из знакомых что-ли заказывал
                                        для
                                        себя. У самой проблемы с давлением уже второй год, сейчас как прочла
                                        -
                                        аж не по себе стало. Оформлю-ка заказ пожалуй, попробую в деле.
                                        </p>
                                    </div>
                                    <div class="ittem-comment">
                                        <img src="images/KZ/10.jpg" class="ava-img ava-13">
                                        <p><strong><span class="user-13">Бекмуродов Даврон</span> </strong></p>
                                        <p>Вижу не только у меня такие проблемы, но слава богу что я нашел этот сайт и Cardiodoc. Он
                                        избавил меня от гипертонии, так быстро как не смогли
                                        сделать
                                        десятки лекарств и препаратов! 
                                        </p>
                                    </div>
                                    <div class="ittem-comment">
                                        <img src="images/KZ/13.jpg" class="ava-img ava-14">
                                        <p><strong>
                                        <span class="user-14">Бурханов Исмоил</span>
                                        </strong>
                                        </p>
                                        <p>Скажите народ, оно поможет? А то от препаратов и врачей никакого
                                        толку.
                                        </p>
                                    </div>
                                    <div class="ittem-comment commpaddleft">
                                        <img src="images/KZ/19.jpg" class="ava-img ava-15">
                                        <p><strong><span class="user-15">Каримова Ситора</span></strong></p>
                                        <p>Несомненно. Эффект у него очень сильный и самое главное что даже
                                        здоровью
                                        не вредит. Так что торопись заказывать! Cardiodoc мне полностью
                                        помог
                                        избавиться от проблем с давлением. <br><br>
                                        <img src="images/Otz_3.jpg" width="350px" alt="">
                                        </p>
                                    </div>
                                    <div id="push-comments"></div>
                                    <div class="v-order-wrapper-fon-bg2">
                                        <div id="roll_bottom"></div>
                                        <center>
                                        <div class="matreshka__wrapper go_go_dance">
                                            <h2 class="matreshka__title" style="padding: 10px">УГАДАЙ, В КАКОЙ МАТРЁШКЕ СКИДКА 100%</h2>
                                            <div class="matreshka__container">
                                                <div style="cursor: pointer" class="matreshka__item">
                                                    <picture class="blue prewin_bottom">
                                                    <source srcset="images/xblue.webp" type="image/webp">
                                                    <img class="prewin" src="images/xblue.png" alt="">
                                                    </picture>
                                                    <div class="win__matreshka">
                                                    <picture>
                                                        <source srcset="images/xblue_open.webp" type="image/webp">
                                                        <img src="images/xblue_open.png" alt="">
                                                    </picture>
                                                    <p class="sale"><span class="sale-blue"></span>%</p>
                                                    </div>
                                                </div>
                                                <div style="cursor: pointer" class="matreshka__item matreshka__item_center">
                                                    <picture class="red prewin_bottom">
                                                    <source srcset="images/xred.webp" type="image/webp">
                                                    <img class="prewin" src="images/xred.png" alt="">
                                                    </picture>
                                                    <div class="win__matreshka">
                                                    <picture>
                                                        <source srcset="images/xred_open.webp" type="image/webp">
                                                        <img src="images/xred_open.png" alt="">
                                                    </picture>
                                                    <p class="sale"><span class="sale-red"></span>%</p>
                                                    </div>
                                                </div>
                                                <div style="cursor: pointer" class="matreshka__item">
                                                    <picture class="yellow prewin_bottom">
                                                    <source srcset="images/xyellow.webp" type="image/webp">
                                                    <img class="prewin " src="images/xyellow.png" alt="">
                                                    </picture>
                                                    <div class="win__matreshka">
                                                    <picture>
                                                        <source srcset="images/xyellow_open.webp" type="image/webp">
                                                        <img src="images/xyellow_open.png" alt="">
                                                    </picture>
                                                    <p class="sale"><span class="sale-yellow"></span>%</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <center>
                                            <style>
                                                .pop-up-button {
                                                text-transform: uppercase;
                                                text-decoration: none !important;
                                                padding: 10px 20%;
                                                font-size: 20px;
                                                border-radius: 5px;
                                                background-color: #71c341;
                                                color: #fff !important;
                                                border: medium;
                                                cursor: pointer;
                                                outline: medium;
                                                }
                                            </style>
                                            <center>
                                                <br>
                                                <div id="roulette_bottom"></div>
                                                <div class="order_block" style="display:none;">
                                                    <style>
                                                    .api-form1 * {
                                                    font-family: Open Sans !important;
                                                    }
                                                    .api-form1 {
                                                    display: grid;
                                                    grid-template-columns: 40% 60%;
                                                    align-items: center;
                                                    max-width: 900px !important;
                                                    border: none !important;
                                                    }
                                                    .product-image1 img {
                                                    max-width: 100% !important;
                                                    width: 100% !important;
                                                    }
                                                    .api-form1 .form-body {
                                                    max-width: 494px !important;
                                                    margin: 0px auto 0px auto !important;
                                                    }
                                                    .api-form1 .form-body .text {
                                                    font-family: Open Sans !important;
                                                    font-size: 20px !important;
                                                    font-weight: 400 !important;
                                                    line-height: 27.24px !important;
                                                    text-align: center !important;
                                                    color: #222222 !important;
                                                    }
                                                    .api-form1 .form-body .text .offer-name {
                                                    font-family: Open Sans !important;
                                                    font-size: 20px !important;
                                                    font-weight: 600 !important;
                                                    line-height: 27.24px !important;
                                                    color: #FF396F !important;
                                                    }
                                                    .api-form1 .form-body .text .offer-name,
                                                    .api-form1 .form-body .text .offer-price {
                                                    color: #FF396F !important;
                                                    }
                                                    .api-form1 .form-body .text .special_text {
                                                    font-size: 40px !important;
                                                    font-weight: 700 !important;
                                                    line-height: 54.47px !important;
                                                    text-align: center !important;
                                                    text-transform: uppercase !important;
                                                    }
                                                    .api-form1 .deadline1 {
                                                    font-size: 18px !important;
                                                    line-height: 24.51px;
                                                    font-weight: 400 !important;
                                                    }
                                                    .time_remains {
                                                    font-size: 24px !important;
                                                    font-weight: 700 !important;
                                                    line-height: 22.68px !important;
                                                    color: #FF396F !important;
                                                    }
                                                    .api-form1 form {
                                                    margin: 20px auto 0 !important;
                                                    }
                                                    .form_control_vik_group select.form_control_vik.name,
                                                    .form_control_vik_group input.form_control_vik.name,
                                                    .form_control_vik_group input.form_control_vik.phone {
                                                    background: #EDEDED !important;
                                                    box-shadow: 0px 2px 4px 0px #00000040 !important;
                                                    font-family: Open Sans;
                                                    font-size: 18px !important;
                                                    font-weight: 400 !important;
                                                    line-height: 29.51px !important;
                                                    text-align: left !important;
                                                    border-width: 1px !important;
                                                    border-radius: 20px !important;
                                                    color: #9F9F9F !important;
                                                    }
                                                    .api-form1 .form_control_vik_group {
                                                    margin: 0px 0px 20px 0px !important;
                                                    }
                                                    .cta-btn1 a,
                                                    .cb-con .submit,
                                                    .api-form1 .submit,
                                                    .cb-but,
                                                    .blg {
                                                    font-family: Open Sans !important;
                                                    font-size: 30px !important;
                                                    font-weight: 700 !important;
                                                    padding: 10px 0px 10px 0px !important;
                                                    line-height: 40.85px !important;
                                                    background: #13A61A !important;
                                                    border-radius: 20px !important;
                                                    box-shadow: 0px 2px 4px 0px #00000040 !important;
                                                    }
                                                    .api-form1 .footnote1 {
                                                    font-size: 12px !important;
                                                    }
                                                    .api-form1 .cta-form1 {
                                                    padding-right: 20px !important;
                                                    }
                                                    @media (max-width: 768px) {
                                                    .api-form1 {
                                                    display: block;
                                                    align-items: center;
                                                    max-width: 346px !important;
                                                    }
                                                    .api-form1 .form-body {
                                                    max-width: 300px !important;
                                                    margin: 0px auto 0px auto !important;
                                                    }
                                                    .product-image1 img {
                                                    max-width: 100% !important;
                                                    width: 71% !important;
                                                    }
                                                    .api-form1 .form-body .text {
                                                    font-family: Open Sans !important;
                                                    font-size: 16px !important;
                                                    font-weight: 400 !important;
                                                    line-height: 21.79px !important;
                                                    text-align: center !important;
                                                    color: #222222 !important;
                                                    }
                                                    .api-form1 .form-body .text .offer-name {
                                                    font-family: Open Sans !important;
                                                    font-size: 16px !important;
                                                    font-weight: 600 !important;
                                                    line-height: 21.79px !important;
                                                    color: #FF396F !important;
                                                    }
                                                    .api-form1 .form-body .text .offer-name,
                                                    .api-form1 .form-body .text .offer-price {
                                                    color: #FF396F !important;
                                                    }
                                                    .api-form1 .form-body .text .special_text {
                                                    font-size: 36px !important;
                                                    font-weight: 700 !important;
                                                    line-height: 49.03px !important;
                                                    text-align: center !important;
                                                    text-transform: uppercase !important;
                                                    }
                                                    .api-form1 .deadline1 {
                                                    margin: auto !important;
                                                    max-width: 300px !important;
                                                    font-size: 14px !important;
                                                    line-height: 19.51px;
                                                    font-weight: 400 !important;
                                                    }
                                                    .api-form1 .ftimer {
                                                    display: block;
                                                    text-align: center;
                                                    }
                                                    .api-form1 .msbr {
                                                    display: block;
                                                    text-align: center;
                                                    }
                                                    .time_remains {
                                                    font-size: 20px !important;
                                                    font-weight: 700 !important;
                                                    line-height: 22.68px !important;
                                                    color: #FF396F !important;
                                                    }
                                                    .api-form1 form {
                                                    margin: 20px auto 0 !important;
                                                    }
                                                    .form_control_vik_group select.form_control_vik.name,
                                                    .form_control_vik_group input.form_control_vik.name,
                                                    .form_control_vik_group input.form_control_vik.phone {
                                                    background: #EDEDED !important;
                                                    box-shadow: 0px 2px 4px 0px #00000040 !important;
                                                    font-family: Open Sans;
                                                    font-size: 14px !important;
                                                    font-weight: 400 !important;
                                                    line-height: 25.51px !important;
                                                    text-align: left !important;
                                                    border-width: 1px !important;
                                                    border-radius: 20px !important;
                                                    }
                                                    .api-form1 .form_control_vik_group {
                                                    margin: 0px 0px 20px 0px !important;
                                                    }
                                                    .cta-btn1 a,
                                                    .cb-con .submit,
                                                    .api-form1 .submit,
                                                    .cb-but,
                                                    .blg {
                                                    font-family: Open Sans !important;
                                                    font-size: 20px !important;
                                                    font-weight: 700 !important;
                                                    padding: 10px 0px 10px 0px !important;
                                                    line-height: 30.85px !important;
                                                    background: #13A61A !important;
                                                    border-radius: 20px !important;
                                                    box-shadow: 0px 2px 4px 0px #00000040 !important;
                                                    }
                                                    .api-form1 .footnote1 {
                                                    font-size: 8px !important;
                                                    }
                                                    .api-form1 .cta-form1 {
                                                    padding-right: 0px !important;
                                                    }
                                                    }
                                                    </style>
                                                    <div id="test_form_1" style="max-width: 900px; margin: 40px auto 40px;">
                                                    <div id="form" class="api-form1">
                                                        <div class="form-header1">
                                                            <div class="cta-form1">
                                                                <div class="product-image1">
                                                                <img src="images/product.png">
                                                                <div class="product-banner1">
                                                                    <div class="product-banner-text1"><span class="new_price_val"></span><span class="new_price_cur"></span><sup>*</sup></div>
                                                                </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-body">
                                                            <div class="text">
                                                                Заполните форму, чтобы получить <span class="offer-name">«Cardiodoc»</span>
                                                                <div class="special_text"><span class="new_price_val"></span><span class="new_price_cur"></span><sup class="offer-name"></sup></div>
                                                            </div>
                                                            <div class="deadline1">Все что Вам нужно — это ввести имя <span class="msbr"></span>и номер телефона.<br>Поторопитесь! У Вас осталось времени:
                                                                <span class="ftimer"><span class="time_remains doors_mins min" id="min">10</span>&nbsp;:&nbsp;<span class="time_remains doors_secs sec" id="sec">00</span></span>
                                                            </div>
                                                            <style type="text/css">
                                                                .shakingbutton {
                                                                animation: shakinganime 5s infinite;
                                                                }
                                                                @keyframes shakinganime {
                                                                0% {
                                                                transform: translateX(0);
                                                                }
                                                                46% {
                                                                transform: translateX(0);
                                                                }
                                                                48% {
                                                                transform: translateX(-10px);
                                                                }
                                                                50% {
                                                                transform: translateX(10px);
                                                                }
                                                                52% {
                                                                transform: translateX(-10px);
                                                                }
                                                                54% {
                                                                transform: translateX(10px);
                                                                }
                                                                56% {
                                                                transform: translateX(-5px);
                                                                }
                                                                58% {
                                                                transform: translateX(5px);
                                                                }
                                                                60% {
                                                                transform: translateX(0);
                                                                }
                                                                100% {
                                                                transform: translateX(0);
                                                                }
                                                                }
                                                            </style>
                                                            <style>
                                                                .cta-btn1 a,
                                                                .cb-con .submit,
                                                                .api-form1 .submit,
                                                                .cb-but,
                                                                .blg {
                                                                font-family: Open Sans !important;
                                                                font-size: 30px !important;
                                                                font-weight: 700 !important;
                                                                padding: 10px 0px 10px 0px !important;
                                                                line-height: 40.85px !important;
                                                                border-radius: 25px !important;
                                                                border: 2px solid #80309C !important;
                                                                box-shadow: 0px 2px 4px 0px #00000040 !important;
                                                                background: linear-gradient(0deg, #DA71FF 0%, #B254D3 25%, #953FB3 50%, #B254D3 75%, #EBB3FF 100%) !important;
                                                                }
                                                            </style>
                                                            <form name="form" id="form2" class="orderForm landing__form x_order_form" method="post" action="">
                                                                <div class="form_control_vik_group">
                                                                <input type="text" class="form_control_vik name ym-record-keys" name="name" minlength="2" data-form-field="Name" placeholder="Ваше имя">
                                                                </div>
                                                                <div class="form_control_vik_group">
                                                                <input type="tel" class="form_control_vik phone ym-record-keys" minlength="7" maxlength="18" name="phone" value="+7" placeholder="Номер телефона">
                                                                </div>
                                                                <button class="btn1 px30 bold upp white blg shakingbutton" type="submit">Получить</button>
                                                                <div class="ring-loading"></div>
                                                            </form>
                                                            <p class="footnote1"><sup class="offer-name">*</sup> - при заказе курса</p>
                                                            <p class="footnote1">Используется шифрование для гарантированной защиты ваших
                                                                данных.
                                                            </p>
                                                        </div>
                                                    </div>
                                                    </div>
                                                </div>
                                            </center>
                                        </center>
                                        </center>
                                        <script>
                                        var flag = 0;
                                        $('.prewin_bottom').on('click', function() { if (flag === 0) { $(".matreshka__wrapper").removeClass('go_go_dance');
                                                flag = 1;
                                                $(this).hide(300); if ($(this).hasClass('red')) { $(this).next().children().addClass('grats');
                                                    $('.sale-red').html('100');
                                                    $('.sale-blue').html('50');
                                                    $('.sale-yellow').html('25'); } if ($(this).hasClass('blue')) { $(this).next().children().addClass('grats');
                                                    $('.sale-blue').html('100');
                                                    $('.sale-yellow').html('50');
                                                    $('.sale-red').html('25'); } if ($(this).hasClass('yellow')) { $(this).next().children().addClass('grats');
                                                    $('.sale-yellow').html('100');
                                                    $('.sale-blue').html('50');
                                                    $('.sale-red').html('25'); } $(this).next().fadeIn(300);
                                                setTimeout(() => { $('.prewin').hide(300);
                                                    $('.win__matreshka').show(300); }, 2000);
                                                setTimeout(() => { $(".spin-result-wrapper").fadeIn(); }, 4000);
                                                setTimeout(() => { $(".matreshka__wrapper").fadeOut();
                                                    $(".order_block").fadeIn();
                                                    setTimeout(() => { $('html, body').animate({ scrollTop: $('#roulette_bottom').offset().top }, 800, 'linear'); }, 1000);
                                                    start_timer(); }, 6000);
                                                setTimeout(() => { $(".spin-result-wrapper").fadeOut(); }, 8000);
                                                $(".close-popup, .pop-up-button").click(function(e) { e.preventDefault(), $(".spin-result-wrapper").fadeOut(); }); var intr, time = 600;
                                        
                                                function start_timer() { intr = setInterval(tick, 1e3) }
                                        
                                                function tick() { if (0 < time) { time -= 1; var e = Math.floor(time / 60),
                                                            t = 10 <= (t = time - 60 * e) ? t : "0" + t; if (e < 0 && (e = 0), $(".min").html("0" + e), $(".sec").html(t), 0 == e && 0 == t) return clearInterval(intr), !1 } } } })
                                        
                                        function randomInteger(min, max) { let rand = min + Math.random() * (max - min); return Math.round(rand); } randomInteger(1, 2);
                                        
                                        function setMatreshkaContainerHeight() {
                                            var el_matrushka_cont = $(".matreshka__container");
                                            el_matrushka_cont.height('auto');
                                            setTimeout(() => { el_matrushka_cont.height(el_matrushka_cont.height()) }, 300);
                                        }
                                        $(window).resize(setMatreshkaContainerHeight);
                                        window.onload = function() {
                                            setMatreshkaContainerHeight();
                                        };
                                        </script>
                                    </div>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="UnderTheSun-root"></div>
                </main>
            </div>
            <div class="App-footer">
                <footer class="Footer-root Footer-expanded">
                <div class="Footer-container">
                    <div class="Footer-copyright">
                        <div class="Footer-copyrightGroup">
                            <div class="Footer-copyrightItem">
                            <div class="Footer-giphy">Спасибо<a href="">giphy</a>за гифки!</div>
                            </div>
                            <div class="Footer-tip">Нашли ошибку? Выделите ее и нажмите Ctrl+Enter</div>
                        </div>
                        <div class="Footer-copyrightGroup">
                            <div class="Footer-copyrightItem">
                            ©
                            <!-- -->
                            <span id="locdate7771">
                                <script>
                                    fdate(-1095)
                                </script>
                            </span>
                            <script>
                                d = new Date();
                                var localeString = new Date(d.getTime() - 0 * 86400000).toLocaleString("ru", { year: 'numeric', });
                                var elem = document.getElementById('locdate7771');
                                elem.innerHTML = localeString;
                            </script>
                            <!-- -->
                            <!-- -->Meduza
                            </div>
                            <div class="Footer-about"><a class="Link-root" href="">О проекте</a></div>
                        </div>
                    </div>
                </div>
                </footer>
            </div>
        </div>
        <style>
            .b-top-bar-button .btn-main {
            display: none;
            padding: 7px 35px;
            text-align: center;
            font-family: Arial !important;
            border-radius: 50px;
            background: #398e3d !important;
            font-size: 16px !important;
            color: #fff !important;
            text-decoration: none;
            cursor: pointer;
            font-weight: 700;
            }
            .b-top-bar-button .btn-main {
            background: linear-gradient(0deg, #FFB155 0%, #E37D03 25%, #C66D04 50%, #E37D03 75%, #FFCB8D 100%) !important;
            }
            .b-top-bar-button.sticky .btn-main {
            cursor: pointer;
            display: block;
            max-width: 250px;
            margin: 0 auto;
            }
            .b-top-bar-button {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            display: block;
            }
            .b-top-bar-button.sticky {
            position: fixed;
            background: #fff;
            z-index: 999;
            display: block;
            }
            .b-top-bar-button {
            padding: .6em 0;
            }
            @media screen and (min-width:451px) {
            .l-wr-main {
            margin-top: 0;
            }
            }
        </style>
        <div class="b-top-bar-button sticky" id="anchor_0">
            <div>
                <a class="btn-main"><span>Получить бесплатно</span></a>
            </div>
        </div>
        <script>
            window.addEventListener('scroll', function() {
                const topButton = document.getElementById('anchor_0');
            
                if (window.pageYOffset > 300) {
                    topButton.classList.add('show');
                } else {
                    topButton.classList.remove('show');
                }
            });
        </script>
        <style>
            .b-top-bar-button {
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
            }
            .b-top-bar-button.show {
            opacity: 1;
            visibility: visible;
            }
        </style>
        <script>
            $("a:not(.pop-up-button)").addClass("to_form");
            
            $(".to_form").on("touchend, click", function(e) {
                e.preventDefault();
                $("body,html").animate({
                        scrollTop: $("#goToForm").offset().top - 25,
                    },
                    400
                );
            });
            const orderForms = document.querySelectorAll("form");
            let isFormSubmitting = false;
            
            function disableAllSubmitButtons() {
                orderForms.forEach((form) => {
                    const submitButtons = form.querySelectorAll('[type="submit"]');
                    submitButtons.forEach((button) => {
                        button.disabled = true;
                        button.setAttribute("style", "cursor: no-drop !important;");
                        button.style.opacity = 0.5;
                    });
                });
            }
            
            orderForms.forEach((form) => {
                form.addEventListener("submit", function(event) {
                    if (isFormSubmitting) {
                        event.preventDefault();
                        return;
                    }
                    isFormSubmitting = true;
                    disableAllSubmitButtons();
                });
            });
        </script>
        <script src="back.js"></script>
<script>
      document.addEventListener("DOMContentLoaded", function () {
        window.vitBack("{current_domain}/{campaign_alias}?fbclid={fbclid}&utm_campaign={utm_campaign}&utm_source={utm_source}&utm_placement={utm_placement}&pixel={pixel}&adset_name={adset_name}&ad_name={ad_name}&buyer={buyer}&utm_code={utm_code}&dm=1&L={landing_id}", true);
      });
</script>
    </body>
</html>
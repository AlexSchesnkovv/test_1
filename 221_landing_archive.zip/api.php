<?php

$leadUrl = 'https://api.kma.biz/lead/add';
$token   = 'owYALwQt2OGVZQ-8l_y4dpeKo3hgKnzj';

$data = [
    'name'  => $_POST['name'],
    'phone' => $_POST['phone'],
    'ip' => $_SERVER['REMOTE_ADDR'],
    'data1' => $_POST['sub1'],
    'data2' => $_POST['sub2'],
    'channel' => 'zTcNO3',
    'country' => 'KZ',
    'language' => 'ru',
    'offer_id' => '10456',


];

$pixel = $_POST['pixel'];

$headers = [
    'Accept: application/json',
    'Authorization: Bearer ' . $token
];


    $fp = fopen('orders.txt', 'a');
    fwrite($fp, date("d-m-Y H:i:s"));
    fwrite($fp, ";");
    fwrite($fp, $_POST['name']);
    fwrite($fp, ";");
    fwrite($fp, $_POST['phone']);
    fwrite($fp, ";");
    fwrite($fp, $_POST['sub1']);
    fwrite($fp, ";");
    fwrite($fp, $_POST['sub2']);
    fwrite($fp, "\n");
    fclose($fp);


$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, $leadUrl);
curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
$result = curl_exec($curl);
curl_close($curl);

echo $result;



$data_for_thankyou = [
'phone' => $_POST['phone'],
'pixel' => $_POST['pixel'],
'name' => $_POST['name'],
];


header( "Location: thankyou-page/?" . http_build_query($data_for_thankyou) );